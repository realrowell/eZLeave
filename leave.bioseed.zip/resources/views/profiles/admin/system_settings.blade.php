@extends('includes.admin_layout')
@section('title','Area of Assignments')
@section('sidebar_settings_active','active')
@section('content')

settings

@endsection
