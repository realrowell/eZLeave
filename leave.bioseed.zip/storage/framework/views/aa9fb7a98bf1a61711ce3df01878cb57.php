<?php $__env->startSection('grid_view_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>

<div class="row g-4 justify-content-sm-center justify-content-md-start justify-content-lg-start">
    <?php if($leave_applications->isNotEmpty()): ?>
        <?php $__currentLoopData = $leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-sm-10">
                <div class="card w-100 p-2 shadow">
                    <div class="card-body">
                        <h4 class="card-title text-center"><?php echo e($leave_application->leavetypes->leave_type_title); ?></h4>
                        <div class="row">
                            <div class="col">
                                <p class="card-text" id="approval_p">Reference #:</p>
                                <h5> <?php echo e($leave_application->reference_number); ?></h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-4">
                                <p class="card-text" id="approval_p">Start date:</p>
                                <h5> <?php echo e(\Carbon\Carbon::parse($leave_application->start_date)->format('M d, Y')); ?></h5>
                            </div>
                            <div class="col-4">
                                <p class="card-text" id="approval_p">End date:</p>
                                <h5> <?php echo e(\Carbon\Carbon::parse($leave_application->end_date)->format('M d, Y')); ?></h5>
                            </div>
                            <div class="col-4">
                                <p class="card-text" id="approval_p">Duration:</p>
                                <h5><?php echo e($leave_application->duration); ?></h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <p class="card-text" id="approval_p">Date of application:</p>
                                <h5> <?php echo e(\Carbon\Carbon::parse($leave_application->created_at)->format('M d, Y - h:i:sa')); ?></h5>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col">
                                <p class="card-text" id="approval_p">Approver:</p>
                                <h6>
                                    <?php echo e(optional($leave_application->approvers->users)->first_name); ?>

                                    <?php echo e(optional($leave_application->approvers->users)->last_name); ?>

                                    <?php echo e(optional(optional($leave_application->approvers->users)->suffixes)->suffix_title); ?>

                                </h6>
                            </div>
                            <div class="col">
                                <?php if($leave_application->second_approver_id != null): ?>
                                    <p class="card-text" id="approval_p">Second Approver:</p>
                                    <h6 class="">
                                        <?php echo e(optional(optional($leave_application->second_approvers)->users)->first_name); ?>

                                        <?php echo e(optional(optional($leave_application->second_approvers)->users)->last_name); ?>

                                        <?php echo e(optional(optional(optional($leave_application->second_approvers)->users)->suffixes)->suffix_title); ?>

                                    </h6>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <p class="card-text" id="approval_p">Status:</p>
                                <?php if($leave_application->status_id == 'sta-1001'): ?>
                                    <p class="bg-secondary text-light ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                <?php elseif($leave_application->status_id == 'sta-1002'): ?>
                                    <p class="bg-success text-light ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                <?php elseif($leave_application->status_id == 'sta-1003'): ?>
                                    <p class="bg-secondary text-light ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                <?php elseif($leave_application->status_id == 'sta-1004'): ?>
                                    <p class="bg-danger text-light ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                <?php elseif($leave_application->status_id == 'sta-1005'): ?>
                                    <p class="bg-warning text-dark ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="d-grid gap-2">
                                    <button class="btn btn-sm btn-primary text-center" data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo e($leave_application->reference_number); ?>">View Details</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- leave details Modal -->
                <div class="modal fade" id="detailsModal<?php echo e($leave_application->reference_number); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="modal-title">Leave Details</h5>
                                        </div>
                                        <div class="col text-end">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid text-start">
                                    <div class="row">
                                        <div class="col-lg-3 col-md-12 col-sm-12 bg-pattern-1 text-light text-center justify-content-center align-items-center">
                                            <h2></h2>
                                        </div>
                                        <div class="col-lg-9 col-md-12 col-sm-12">
                                            <div class="row">
                                                <div class="col">
                                                    <label for="employee">
                                                        <h6 class="">Reference Number</h6>
                                                    </label>
                                                    <h4><?php echo e($leave_application->reference_number); ?></h4>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col">
                                                    <label class="" for="leavetype">
                                                        <h6 class="">Leave Type</h6>
                                                    </label>
                                                    <h4><?php echo e(optional($leave_application->leavetypes)->leave_type_title); ?></h4>
                                                </div>
                                                <div class="col">
                                                    <label for="duration">
                                                        <h6>Duration</h6>
                                                    </label>
                                                    <h4><?php echo e($leave_application->duration); ?></h4>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-6">
                                                    <label for="startdate">
                                                        <h6>Start date</h6>
                                                    </label>
                                                    <h4><?php echo e(\Carbon\Carbon::parse($leave_application->start_date)->format('M d, Y')); ?> (<?php echo e($leave_application->start_of_date_parts->day_part_title); ?>)</h4>
                                                </div>
                                                <div class="col-6">
                                                    <label for="enddate">
                                                        <h6>End date</h6>
                                                    </label>
                                                    <h4><?php echo e(\Carbon\Carbon::parse($leave_application->end_date)->format('M d, Y')); ?> (<?php echo e($leave_application->end_of_date_parts->day_part_title); ?>)</h4>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col">
                                                    <label for="enddate">
                                                        <h6>Date filed</h6>
                                                    </label>
                                                    <h4><?php echo e(\Carbon\Carbon::parse($leave_application->created_at)->format('M d, Y h:i:s A')); ?></h4>
                                                </div>
                                            </div>
                                            <div class="row mt-4">
                                                <div class="col">
                                                    <label for="employee">
                                                        <h6 class="">Approver</h6>
                                                    </label>
                                                    <h4>
                                                        <?php echo e(optional($leave_application->approvers->users)->first_name); ?>

                                                        <?php echo e(optional($leave_application->approvers->users)->last_name); ?>

                                                        <?php echo e(optional($leave_application->approvers->users->suffixes)->suffix_title); ?>

                                                    </h4>
                                                </div>
                                                <div class="col">
                                                    <label for="employee">
                                                        <h6 class="">Second Approver</h6>
                                                    </label>
                                                    <h4>
                                                        <?php if($leave_application->second_approver_id == null): ?>
                                                            N/A
                                                        <?php else: ?>
                                                            <?php echo e(optional(($leave_application->second_approvers)->users)->first_name); ?>

                                                            <?php echo e(optional($leave_application->second_approvers->users)->last_name); ?>

                                                            <?php echo e(optional($leave_application->second_approvers->users->suffixes)->suffix_title); ?>

                                                        <?php endif; ?>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col">
                                                    <?php if(!empty($leave_application->attachment)): ?>
                                                        <a target="_blank" href="<?php echo e(asset('storage/images/'.$leave_application->attachment)); ?>">View Attachment</a>
                                                    <?php else: ?>
                                                        <label for="">No Attachment</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col">
                                                    <label class="" for="reason">
                                                        <h6 class="">Reason / Note</h6>
                                                    </label>
                                                    <?php $__currentLoopData = $leave_application_notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_application_note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($leave_application_note->leave_application_reference == $leave_application->reference_number): ?>
                                                            <textarea class="form-control" disabled><?php echo e($leave_application_note->reason_note); ?></textarea>
                                                            <?php if($leave_application_note->author_id != null): ?>
                                                                <p> - <?php echo e(optional($leave_application_note->users)->first_name); ?> <?php echo e(optional($leave_application_note->users)->last_name); ?> at <?php echo e($leave_application_note->created_at); ?></p>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col">
                                                    <label class="" for="status">
                                                        <h6 class="">Status</h6>
                                                    </label>
                                                    <?php if($leave_application->status_id == 'sta-1001'): ?>
                                                        <?php $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($leave_approval->leave_application_reference == $leave_application->reference_number): ?>
                                                                <?php if($leave_approval->status_id == 'sta-1001'): ?>
                                                                    <p class="bg-secondary text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?></p>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($leave_application->status_id == 'sta-1002'): ?>
                                                        <?php $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($leave_approval->leave_application_reference == $leave_application->reference_number): ?>
                                                                <?php if($leave_approval->status_id == 'sta-1001'): ?>
                                                                    <p class="bg-secondary text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?></p>
                                                                <?php elseif($leave_approval->status_id == 'sta-1002'): ?>
                                                                    <p class="bg-success text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($leave_application->status_id == 'sta-1003'): ?>
                                                        <?php $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($leave_approval->leave_application_reference == $leave_application->reference_number): ?>
                                                                <?php if($leave_approval->status_id == 'sta-1001'): ?>
                                                                    <p class="bg-secondary text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?></p>
                                                                <?php elseif($leave_approval->status_id == 'sta-1002'): ?>
                                                                    <p class="bg-success text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($leave_application->status_id == 'sta-1004'): ?>
                                                        <?php $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($leave_approval->leave_application_reference == $leave_application->reference_number): ?>
                                                                <?php if($leave_approval->status_id == 'sta-1001'): ?>
                                                                    <p class="bg-secondary text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?></p>
                                                                <?php elseif($leave_approval->status_id == 'sta-1002'): ?>
                                                                    <p class="bg-success text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                <?php elseif($leave_approval->status_id == 'sta-1004'): ?>
                                                                    <p class="bg-danger text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($leave_application->status_id == 'sta-1005'): ?>
                                                        <?php $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($leave_approval->leave_application_reference == $leave_application->reference_number): ?>
                                                                <?php if($leave_approval->status_id == 'sta-1001'): ?>
                                                                    <p class="bg-secondary text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?></p>
                                                                <?php elseif($leave_approval->status_id == 'sta-1002'): ?>
                                                                    <p class="bg-success text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                <?php elseif($leave_approval->status_id == 'sta-1004'): ?>
                                                                    <p class="bg-danger text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                <?php elseif($leave_approval->status_id == 'sta-1005'): ?>
                                                                    <p class="bg-warning text-dark ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <a href="<?php echo e(route('leave_details_page',['leave_application_rn'=>$leave_application->reference_number])); ?>" class="btn btn-primary text-center">View in Detailed</a>
                                <button type="button" class="btn btn-light border-primary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="row align-items-center justify-content-center mt-5">
            <div class="col text-center">
                <h2>No leave application found!</h2>
            </div>
        </div>
    <?php endif; ?>
</div>
<div class="row">
    <div class="col">
        <div class="mt-2 mb-5">
            <ul class="pagination justify-content-center align-items-center">
                <?php echo $leave_applications->links('pagination::bootstrap-5'); ?>

            </ul>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.employee.leave_management.history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/employee/leave_management/history_grid.blade.php ENDPATH**/ ?>