<?php $__env->startSection('grid_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>

<div class="row mt-2">
    <div class="col-lg-6 col-md-6 col-sm-12">

    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="row">
            <div class="input-group">
                <input type="search" class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                <button type="button" class="btn btn-primary">search</button>
            </div>
        </div>
        <div class="row">
            <p>*Search position title here</p>
        </div>
    </div>
</div>
    
<div class="row g-4 justify-content-sm-center justify-content-md-start justify-content-lg-start">
    <div class="">
        <?php $__empty_1 = true; $__currentLoopData = $view_subdepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_subdepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row ">
                <h3><?php echo e($view_subdepartment->sub_department_title); ?></h3>
            </div>
            <div class="row mb-5 g-4 justify-content-sm-center justify-content-md-start justify-content-lg-start">
                <?php $__empty_2 = true; $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <?php if($position->subdepartments->id == $view_subdepartment->id): ?>
                        <div class="col-lg-4 col-md-6 col-sm-10 d-flex align-items-stretch">
                            <div class="card w-100 p-2 shadow">
                                <div class="card-body row">
                                    <div class="row">
                                        <h5><strong><?php echo e($position->position_description); ?></strong></h5>
                                    </div>
                                    <div class="row">
                                        
                                        <p class="card-desc">Sub-department: <?php echo e($position->subdepartments->sub_department_title); ?></p>
                                        <p class="card-desc">Department: <?php echo e($position->subdepartments->departments->department_title); ?></p>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col">
                                            <a href="#View_position" class="btn btn-sm btn-primary text-center">View</a>
                                            <a href="#Update_position" class="btn btn-sm btn-outline-primary border border-primary" data-bs-toggle="modal" data-bs-target="#update_position<?php echo e($position->id); ?>" title="Update">Update</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Update Department Modal -->
                            <div class="modal fade" id="update_position<?php echo e($position->id); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('admin_update_position',['id'=>$position->id])); ?>" method="PUT" onsubmit="submitButtonDisabled()">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="staticBackdropLabel">Update Position</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="container-fluid text-start">
                                                    <div class="row mt-2 mb-3" >
                                                        <div class="col">
                                                            <label for="position_title"><h6 class="profile-title">Position title</h6></label>
                                                            <select id="position_title" name="position_title" class="form-control" required>
                                                                <option selected required value="<?php echo e($position->position_titles->id); ?>"><?php echo e($position->position_titles->position_title); ?></option>
                                                                <?php $__currentLoopData = $position_titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position_title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($position_title->id); ?>"><?php echo e($position_title->position_title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <label class="mt-3" for="position_title"><h6 class="profile-title">Position description</h6></label>
                                                            <textarea class="form-control" id="position_description" name="position_description" rows="3    " cols="50" required><?php echo e($position->position_description); ?></textarea>
                                                            <label class="mt-3" for="subdepartment_title"><h6 class="profile-title">Sub-department</h6></label>
                                                            <select id="subdepartment_title" name="subdepartment_title" class="form-control" required>
                                                                <option selected required value="<?php echo e($position->subdepartment_id); ?>"><?php echo e($position->subdepartments->sub_department_title); ?></option>
                                                                <?php $__currentLoopData = $subdepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($subdepartment->id); ?>"><?php echo e($subdepartment->sub_department_title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <label class="mt-3" for="position_level"><h6 class="profile-title">Position Level</h6></label>
                                                            <select id="position_level" name="position_level" class="form-control" required>
                                                                <option selected required value="<?php echo e($position->position_level_id); ?>"><?php echo e(optional($position->position_levels)->level_title); ?></option>
                                                                <?php $__currentLoopData = $position_levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position_level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($position_level->id); ?>"><?php echo e($position_level->level_title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <div class="form-check form-switch mt-3">
                                                                <input class="form-check-input" type="checkbox" id="is_hod1" name="is_hod"
                                                                    <?php
                                                                        if($position->is_hod == true){
                                                                        echo 'checked';
                                                                        }
                                                                    ?>>
                                                                <label class="form-check-label" for="is_hod1">Head of Department</label>
                                                            </div>
                                                            <div class="form-check form-switch mt-3">
                                                                <input class="form-check-input" type="checkbox" id="is_hr_manager1" name="is_hr_manager"
                                                                    <?php
                                                                        if($position->is_hr_manager == true){
                                                                        echo 'checked';
                                                                        }
                                                                    ?>>
                                                                <label class="form-check-label" for="is_hr_manager1">HR Manager</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Discard</button>
                                                <button id="submit_button2" type="submit" class="btn btn-success" >Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Delete Department Modal -->
                            <div class="modal fade " id="delete_position_<?php echo e($position->id); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('admin_delete_position',['id'=>$position->id])); ?>" method="PUT" onsubmit="submitButtonDisabled()">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="staticBackdropLabel">Delete position</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="container-fluid text-start">
                                                    <div class="row mt-2 mb-3" >
                                                        <div class="col">
                                                            <label class="mb-3"><h6 class="profile-title">Are you sure you want to delete this?</h6></label>
                                                            <p class="card-desc"><b><?php echo e($position->position_title); ?></b> </p>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outlined" data-bs-dismiss="modal">Discard</button>
                                                <button id="submit_button2" type="submit" class="btn btn-danger" >Confirm</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <div class="col-lg-4 col-md-6 col-sm-10 d-flex align-items-stretch">
                        No Data Available
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No Data Available
        <?php endif; ?>
        <div class="row">
            <div class="col">
                <div class="mt-2 mb-5">
                    <ul class="pagination justify-content-center align-items-center">
                        <?php echo $view_subdepartments->links('pagination::bootstrap-5'); ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.admin.organization.positions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/admin/organization/positions_grid.blade.php ENDPATH**/ ?>