<?php $__env->startSection('grid_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>



    
<div class="row g-4 justify-content-sm-center justify-content-md-start justify-content-lg-start">
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 col-sm-10 d-flex align-items-stretch">
            <div class="card w-100 p-2 shadow">
                <div class="card-body row">
                    
                    <div class="">
                        <div class="row">
                            <h5><strong><?php echo e($department->department_title); ?></strong></h5>
                        </div>
                        <div class="row">
                            <p class="card-desc">
                                <?php
                                    echo App\Models\Employee::all()->where('id',optional($department->subdepartments->positions->employee_positions)->employee_id)->count();
                                ?>
                            </p>
                            <p class="card-desc">Sub-departments:
                                <?php
                                    echo App\Models\SubDepartment::where('department_id',$department->id)->count();
                                ?>
                            </p>
                        </div>
                        <div class="row mt-2">
                            <div class="col">
                                <a href="#" class="btn btn-sm btn-primary text-center">View</a>
                                <a href="#Update_department" class="btn btn-sm btn-outline-primary border border-primary" data-bs-toggle="modal" data-bs-target="#update_department<?php echo e($department->id); ?>">
                                    Update
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Update Department Modal -->
        <div class="modal fade" id="update_department<?php echo e($department->id); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin_update_department',['id'=>$department->id])); ?>" method="PUT" onsubmit="submitButtonDisabled()">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Update Department</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid text-start">
                                <div class="row mt-2 mb-3" >
                                    <div class="col">
                                        <label for="department_title"><h6 class="profile-title">Deparment name</h6></label>
                                        <input type="text" class="form-control" id="department_title" name="department_title" placeholder="<?php echo e($department->department_title); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Discard</button>
                            <button id="submit_button2" type="submit" class="btn btn-success">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.admin.organization.departments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/admin/organization/departments_grid.blade.php ENDPATH**/ ?>