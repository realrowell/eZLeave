<?php $__env->startSection('title','Login Logs'); ?>
<?php $__env->startSection('sidebar_dashboard_active','active'); ?>
<?php $__env->startSection('profile_bar_display',''); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col p-5">
            <table id="loginlogs_table" class="table table-sm table-bordered table-hover bg-light shadow" style="width:100%; ">
                <thead class="bg-success text-light border-light" style="font-size:0.9rem; ">
                    <tr>
                        <th>User</th>
                        <th>IP Address</th>
                        <th>Device Info</th>
                        <th>Date Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $login_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $login_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($login_log->users->last_name); ?>, <?php echo e($login_log->users->first_name); ?> <?php echo e(optional($login_log->users->suffixes)->suffix_title); ?></td>
                        <td><?php echo e($login_log->ip_address); ?></td>
                        
                        <td><?php echo e($login_log->device); ?></td>
                        <td><?php echo e($login_log->date_time); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot class="bg-success text-light border-light" style="font-size:0.9rem; ">
                    <tr>
                        <th>User</th>
                        <th>IP Address</th>
                        <th>Device Info</th>
                        <th>Date Time</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/admin/login_logs.blade.php ENDPATH**/ ?>