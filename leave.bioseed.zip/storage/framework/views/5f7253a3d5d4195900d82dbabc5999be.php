<?php $__env->startSection('list_view_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>

<div class="row">
    <div class="spinner-border text-primary" id="loading_spinner_approve" role="status" style="display: none;">
        <span class="visually-hidden" >Loading...</span>
    </div>
    <div id="table_container">
        <div class="table-wrapper">
            <table class="table table-bordered table-hover bg-light">
                <h4>Partially Approved Leave Applications</h4>
                <thead class="bg-success text-light border-light">
                    <tr>
                        <th>Reference Number</th>
                        <th>Approver</th>
                        <th>Second Approver</th>
                        <th>Leave Type</th>
                        <th>Start date</th>
                        <th>End date</th>
                        <th>Duration (days)</th>
                        <th>Filed at</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $partial_leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partial_leave_application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($partial_leave_application->reference_number); ?></td>
                            <td id="table_reports_to">
                                <?php if(!empty($partial_leave_application->approvers)): ?>
                                    <?php echo e(optional($partial_leave_application->approvers->users)->first_name); ?>

                                    <?php echo e(optional($partial_leave_application->approvers->users)->middle_name); ?>

                                    <?php echo e(optional($partial_leave_application->approvers->users)->last_name); ?>

                                <?php else: ?>
                                    Not Available
                                <?php endif; ?>
                            </td>
                            <td id="table_2nd_reports_to">
                                <?php if(!empty($partial_leave_application->second_approvers)): ?>
                                    <?php echo e(optional($partial_leave_application->second_approvers->users)->first_name); ?>

                                    <?php echo e(optional($partial_leave_application->second_approvers->users)->middle_name); ?>

                                    <?php echo e(optional($partial_leave_application->second_approvers->users)->last_name); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(optional($partial_leave_application->leavetypes)->leave_type_title); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($partial_leave_application->start_date)->format('M d, Y')); ?> - <?php echo e($partial_leave_application->start_of_date_parts->day_part_title); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($partial_leave_application->end_date)->format('M d, Y')); ?> - <?php echo e($partial_leave_application->end_of_date_parts->day_part_title); ?></td>
                            <td><?php echo e($partial_leave_application->duration); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($partial_leave_application->created_at)->format('M d, Y; h:i a')); ?></td>
                            <td>
                                <?php if($partial_leave_application->status_id == 'sta-1001'): ?>
                                    <span class="badge bg-secondary"><?php echo e($partial_leave_application->statuses->status_title); ?></span>
                                <?php elseif($partial_leave_application->status_id == 'sta-1003'): ?>
                                    <span class="badge bg-secondary"><?php echo e($partial_leave_application->statuses->status_title); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="d-flex gap-2 pb-3">
                                <button class="btn btn-sm btn-primary text-center" data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo e($partial_leave_application->reference_number); ?>">View Details</button>
                                <a href="<?php echo e(route('employee_leave_approval',$partial_leave_application->reference_number)); ?>" class="btn btn-sm btn-success text-center" id="submit_button" onclick="onClickApprove()">Approve</a>
                                <a href="#" class="btn btn-sm btn-danger text-center" data-bs-toggle="modal" data-bs-target="#rejectleaveModal<?php echo e($partial_leave_application->reference_number); ?>">Reject</a>
                            </td>
                        </tr>
                        <!-- reject details Modal -->
                            <div class="modal fade" id="rejectleaveModal<?php echo e($partial_leave_application->reference_number); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('employee_leave_rejection',$partial_leave_application->reference_number)); ?>" method="PUT" onsubmit="onClickApprove()">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header">
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="container-fluid text-start">
                                                    <div class="row">
                                                        <div class="col text-center">
                                                            <h2>Are you sure?</h2>
                                                        </div>
                                                    </div>
                                                    <div class="row mt-2">
                                                        <div class="col">
                                                            <h5>Reason / Note:</h5>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col">
                                                            <textarea class="form-control" id="reason" name="reason" rows="6" cols=50 maxlength=250 placeholder="add reason / note" required></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-transparent" data-bs-dismiss="modal">Cancel</button>
                                                <button class="btn btn-danger" type="submit">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        
                        <!-- leave details Modal -->
                            <div class="modal fade" id="detailsModal<?php echo e($partial_leave_application->reference_number); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="container-fluid text-start">
                                                <div class="row">
                                                    <div class="col-lg-3 col-md-12 col-sm-12 bg-pattern-1 text-light text-center justify-content-center align-items-center">
                                                        <h2></h2>
                                                    </div>
                                                    <div class="col-lg-9 col-md-12 col-sm-12">
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="employee">
                                                                    <h2 class="">Leave Details</h2>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="employee">
                                                                    <h6 class="">Reference Number</h6>
                                                                </label>
                                                                <h4><?php echo e($partial_leave_application->reference_number); ?></h4>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <label class="" for="leavetype">
                                                                    <h6 class="">Leave Type</h6>
                                                                </label>
                                                                <h4><?php echo e(optional($partial_leave_application->leavetypes)->leave_type_title); ?></h4>
                                                            </div>
                                                            <div class="col-6">
                                                                <label for="duration">
                                                                    <h6>Duration (days)</h6>
                                                                </label>
                                                                <h4> <?php echo e($partial_leave_application->duration); ?></h4>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <label for="startdate">
                                                                            <h6>Start date</h6>
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <h4 id="datetime_startdate"><?php echo e(\Carbon\Carbon::parse($partial_leave_application->start_date)->format('M d, Y')); ?></h4>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <h5 id="datetime_startdate"><?php echo e($partial_leave_application->start_of_date_parts->day_part_title); ?></h5>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-6">
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <label for="enddate">
                                                                            <h6>End date</h6>
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <h4 id="datetime_startdate"><?php echo e(\Carbon\Carbon::parse($partial_leave_application->end_date)->format('M d, Y')); ?></h4>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <h5 id="datetime_startdate"><?php echo e($partial_leave_application->end_of_date_parts->day_part_title); ?></h5>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="enddate">
                                                                    <h6>Date filed</h6>
                                                                </label>
                                                                <h4><?php echo e(\Carbon\Carbon::parse($partial_leave_application->created_at)->format('M d, Y - h:i:s A')); ?></h4>
                                                            </div>
                                                        </div>
                                                        <div class="row mt-4">
                                                            <div class="col">
                                                                <label for="employee">
                                                                    <h6 class="">Application by</h6>
                                                                </label>
                                                                <h5>
                                                                    <?php echo e(optional($partial_leave_application->employees->users)->first_name); ?>

                                                                    <?php echo e(optional($partial_leave_application->employees->users)->last_name); ?>

                                                                    <?php echo e(optional($partial_leave_application->employees->users->suffixes)->suffix_title); ?>

                                                                </h5>
                                                            </div>
                                                        </div>
                                                        <div class="row mt-2">
                                                            <div class="col">
                                                                <?php if(!empty($partial_leave_application->attachment)): ?>
                                                                    <a target="_blank" href="<?php echo e(asset('storage/images/'.$partial_leave_application->attachment)); ?>">View Attachment</a>
                                                                <?php else: ?>
                                                                    <label for="">No Attachment</label>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="row mt-2">
                                                            <div class="col">
                                                                <label class="" for="reason">
                                                                    <h6 class="">Reason / Note</h6>
                                                                </label>
                                                                <?php $__empty_2 = true; $__currentLoopData = $leave_application_notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_application_note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                    <?php if($leave_application_note->leave_application_reference == $partial_leave_application->reference_number): ?>
                                                                        <textarea class="form-control" disabled><?php echo e($leave_application_note->reason_note); ?></textarea>
                                                                        <?php if($leave_application_note->author_id != null): ?>
                                                                            <p> - <?php echo e(optional($leave_application_note->users)->first_name); ?> <?php echo e(optional($leave_application_note->users)->last_name); ?> at <?php echo e($leave_application_note->created_at); ?></p>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                    <b><i>No reason/note</i></b>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <label class="" for="update">
                                                                    <?php if($partial_leave_application->status_id == 'sta-1001' || $partial_leave_application->status_id == 'sta-1003'): ?>
                                                                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updatedetailsModal<?php echo e($partial_leave_application->reference_number); ?>">
                                                                            Add note / comment
                                                                        </button>
                                                                    <?php endif; ?>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="row mt-2">
                                                            <div class="col">
                                                                <label class="" for="status">
                                                                    <h6 class="">Status</h6>
                                                                </label>
                                                                <?php if($partial_leave_application->status_id == 'sta-1003'): ?>
                                                                    <?php $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($leave_approval->leave_application_reference == $partial_leave_application->reference_number): ?>
                                                                            <?php if($leave_approval->status_id == 'sta-1001'): ?>
                                                                                <p class="bg-secondary text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e($leave_approval->approvers->first_name." ". $leave_approval->approvers->last_name); ?></p>
                                                                            <?php elseif($leave_approval->status_id == 'sta-1002'): ?>
                                                                                <p class="bg-success text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e(optional($leave_approval->approvers)->first_name." ". optional($leave_approval->approvers)->last_name); ?> <?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('(M d, Y h:i:sa)')); ?></p>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <form action="<?php echo e(route('employee_leave_rejection',$partial_leave_application->reference_number)); ?>" onsubmit="onClickApprove()">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger" data-bs-dismiss="modal">Reject</button>
                                            </form>
                                            <form action="<?php echo e(route('employee_leave_approval',$partial_leave_application->reference_number)); ?>" onsubmit="onClickApprove()">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-success" id="submit_button2" data-bs-dismiss="modal">Approve</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        <!-- update details Modal -->
                            <div class="modal fade" id="updatedetailsModal<?php echo e($partial_leave_application->reference_number); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('create_note_employee_leaveapplication',['leave_application_rn'=>$partial_leave_application->reference_number])); ?>" id="form_submit" method="POST" onsubmit="submitButtonDisabled()" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <div class="modal-body">
                                                <div class="container-fluid text-start">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-12 col-sm-12 bg-pattern-1 text-light text-center justify-content-center align-items-center">
                                                            <h2></h2>
                                                        </div>
                                                        <div class="col-lg-8 col-md-12 col-sm-12">
                                                            <div class="row">
                                                                <div class="col">
                                                                    <label for="employee">
                                                                        <h6 class="">Reference Number</h6>
                                                                    </label>
                                                                    <h4><?php echo e($partial_leave_application->reference_number); ?></h4>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col">
                                                                    <label class="" for="leavetype">
                                                                        <h6 class="">Leave Type</h6>
                                                                    </label>
                                                                    <input type="text" class="form-control text-start" value="<?php echo e(optional($partial_leave_application->leavetypes)->leave_type_title); ?>" disabled>
                                                                </div>
                                                            </div>
                                                            <div class="row ">
                                                                <div class="col-6">
                                                                    <label for="startdate">
                                                                        <h6>Start date</h6>
                                                                    </label>
                                                                    <input type="date" class="form-control" id="startdate" name="startdate" placeholder="" value="<?php echo e(\Carbon\Carbon::parse($partial_leave_application->start_date)->format('Y-m-d')); ?>" disabled>
                                                                </div>
                                                                <div class="col-6">
                                                                    <label for="enddate">
                                                                        <h6>End date</h6>
                                                                    </label>
                                                                    <input type="date" class="form-control" id="enddate" name="enddate" placeholder="" value="<?php echo e(\Carbon\Carbon::parse($partial_leave_application->end_date)->format('Y-m-d')); ?>" disabled>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-6">
                                                                    <label for="startdate">
                                                                        <h6><?php echo e($partial_leave_application->start_of_date_parts->day_part_description); ?></h6>
                                                                    </label>
                                                                </div>
                                                                <div class="col-6">
                                                                    <label for="enddate">
                                                                        <h6><?php echo e($partial_leave_application->end_of_date_parts->day_part_description); ?></h6>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col">
                                                                    <label for="">Duration (days)</label>
                                                                    <input type="text" name="duration" placeholder="" id="duration_input_update" class="form-control" value="<?php echo e($partial_leave_application->duration); ?>" disabled/>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-4">
                                                                <div class="col">
                                                                    <label for="employee">
                                                                        <h6 class="">Employee</h6>
                                                                    </label>
                                                                    <h5><?php echo e(optional($partial_leave_application->employees->users)->first_name); ?> <?php echo e(optional($partial_leave_application->employees->users)->last_name); ?> <?php echo e(optional($partial_leave_application->employees->users->suffixes)->suffix_title); ?></h5>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="col">
                                                                    <?php if(!empty($leave_application->attachment)): ?>
                                                                        <a target="_blank" href="<?php echo e(asset('storage/images/'.$partial_leave_application->attachment)); ?>">View Attachment</a>
                                                                    <?php else: ?>
                                                                        <i>No Attachment</i>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="col">
                                                                    <label class="" for="reason">
                                                                        <h6 class="">Reason / Note</h6>
                                                                    </label>
                                                                    <?php $__currentLoopData = $leave_application_notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_application_note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($leave_application_note->leave_application_reference == $partial_leave_application->reference_number): ?>
                                                                            <textarea class="form-control" disabled><?php echo e($leave_application_note->reason_note); ?></textarea>
                                                                            <?php if($leave_application_note->author_id != null): ?>
                                                                                <p> - <?php echo e(optional($leave_application_note->users)->first_name); ?> <?php echo e(optional($leave_application_note->users)->last_name); ?> at <?php echo e($leave_application_note->created_at); ?></p>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="col">
                                                                    <textarea class="form-control" id="reason" name="reason" placeholder="add note / comment" rows="5"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="col">
                                                                    <label class="" for="status">
                                                                        <h6 class="">Status</h6>
                                                                    </label>
                                                                    <?php if($partial_leave_application->status_id == 'sta-1001'): ?>
                                                                        <p class="bg-secondary text-light ps-3"><?php echo e($partial_leave_application->statuses->status_title); ?></p>
                                                                    <?php elseif($partial_leave_application->status_id == 'sta-1002'): ?>
                                                                        <p class="bg-success text-light ps-3"><?php echo e($partial_leave_application->statuses->status_title); ?></p>
                                                                    <?php elseif($partial_leave_application->status_id == 'sta-1003'): ?>
                                                                        <p class="bg-success text-light ps-3"><?php echo e($partial_leave_application->statuses->status_title); ?></p>
                                                                    <?php elseif($partial_leave_application->status_id == 'sta-1004'): ?>
                                                                        <p class="bg-danger text-light ps-3"><?php echo e($partial_leave_application->statuses->status_title); ?></p>
                                                                    <?php elseif($partial_leave_application->status_id == 'sta-1005'): ?>
                                                                        <p class="bg-danger text-light ps-3"><?php echo e($partial_leave_application->statuses->status_title); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-transparent" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit1" class="btn btn-success" data-bs-dismiss="modal" onclick="onClickApprove()">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td>
                                <div class="row align-items-center justify-content-center mt-3">
                                    <div class="col text-center">
                                        <h2>No leave application available!</h2>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col">
                <div class="mt-2 mb-5">
                    <ul class="pagination justify-content-center align-items-center">
                        <?php echo $partial_leave_applications->links('pagination::bootstrap-5'); ?>

                    </ul>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <div class="table-wrapper">
                <table class="table table-bordered table-hover bg-light">
                    <h4>Leave Applications for your Approval</h4>
                    <thead class="bg-success text-light border-light">
                        <tr>
                            <th>Reference Number</th>
                            <th>Approver</th>
                            <th>Second Approver</th>
                            <th>Leave Type</th>
                            <th>Start date</th>
                            <th>End date</th>
                            <th>Duration (days)</th>
                            <th>Filed at</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($leave_applications->isNotEmpty()): ?>
                            <?php $__currentLoopData = $leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($leave_application->reference_number); ?></td>
                                    <td id="table_reports_to">
                                        <?php if(!empty($leave_application->approvers)): ?>
                                            <?php echo e(optional($leave_application->approvers->users)->first_name); ?>

                                            <?php echo e(optional($leave_application->approvers->users)->middle_name); ?>

                                            <?php echo e(optional($leave_application->approvers->users)->last_name); ?>

                                        <?php else: ?>
                                            Not Available
                                        <?php endif; ?>
                                    </td>
                                    <td id="table_2nd_reports_to">
                                        <?php if(!empty($leave_application->second_approvers)): ?>
                                            <?php echo e(optional($leave_application->second_approvers->users)->first_name); ?>

                                            <?php echo e(optional($leave_application->second_approvers->users)->middle_name); ?>

                                            <?php echo e(optional($leave_application->second_approvers->users)->last_name); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(optional($leave_application->leavetypes)->leave_type_title); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($leave_application->start_date)->format('M d, Y')); ?> - <?php echo e($leave_application->start_of_date_parts->day_part_title); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($leave_application->end_date)->format('M d, Y')); ?> - <?php echo e($leave_application->end_of_date_parts->day_part_title); ?></td>
                                    <td><?php echo e($leave_application->duration); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($leave_application->created_at)->format('M d, Y; h:i a')); ?></td>
                                    <td>
                                        <?php if($leave_application->status_id == 'sta-1001'): ?>
                                            
                                            <span class="badge bg-secondary"><?php echo e($leave_application->statuses->status_title); ?></span>
                                        <?php elseif($leave_application->status_id == 'sta-1002'): ?>
                                            <p class="bg-success text-light ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                        <?php elseif($leave_application->status_id == 'sta-1003'): ?>
                                            <p class="bg-success text-light ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                        <?php elseif($leave_application->status_id == 'sta-1004'): ?>
                                            <p class="bg-danger text-light ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                        <?php elseif($leave_application->status_id == 'sta-1005'): ?>
                                            <p class="bg-warning text-dark ps-3 pe-2"><?php echo e($leave_application->statuses->status_title); ?></p>
                                        <?php endif; ?>
                                    </td>
                                    <td class="d-flex gap-2 pb-3">
                                        <button class="btn btn-sm btn-primary text-center" data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo e($leave_application->reference_number); ?>">View Details</button>
                                        <a href="<?php echo e(route('employee_leave_approval',$leave_application->reference_number)); ?>" class="btn btn-sm btn-success text-center" id="submit_button" onclick="onClickApprove()">Approve</a>
                                        <a href="#" class="btn btn-sm btn-danger text-center" data-bs-toggle="modal" data-bs-target="#rejectleaveModal<?php echo e($leave_application->reference_number); ?>">Reject</a>
                                    </td>
                                </tr>
                                <!-- reject details Modal -->
                                    <div class="modal fade" id="rejectleaveModal<?php echo e($leave_application->reference_number); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('employee_leave_rejection',$leave_application->reference_number)); ?>" method="PUT" onsubmit="onClickApprove()">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-header">
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="container-fluid text-start">
                                                            <div class="row">
                                                                <div class="col text-center">
                                                                    <h2>Are you sure?</h2>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="col">
                                                                    <h5>Reason / Note:</h5>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col">
                                                                    <textarea class="form-control" id="reason" name="reason" rows="6" cols=50 maxlength=250 placeholder="add reason / note" required></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-transparent" data-bs-dismiss="modal">Cancel</button>
                                                        <button class="btn btn-danger" type="submit">Reject</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                
                                <!-- leave details Modal -->
                                    <div class="modal fade" id="detailsModal<?php echo e($leave_application->reference_number); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="container-fluid text-start">
                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-12 col-sm-12 bg-pattern-1 text-light text-center justify-content-center align-items-center">
                                                                <h2></h2>
                                                            </div>
                                                            <div class="col-lg-8 col-md-12 col-sm-12">
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <label for="employee">
                                                                            <h2 class="">Leave Details</h2>
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <label for="employee">
                                                                            <h6 class="">Reference Number</h6>
                                                                        </label>
                                                                        <h4><?php echo e($leave_application->reference_number); ?></h4>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-6">
                                                                        <label class="" for="leavetype">
                                                                            <h6 class="">Leave Type</h6>
                                                                        </label>
                                                                        <h4><?php echo e(optional($leave_application->leavetypes)->leave_type_title); ?></h4>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <label for="duration">
                                                                            <h6>Duration (days)</h6>
                                                                        </label>
                                                                        <h4> <?php echo e($leave_application->duration); ?></h4>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-6">
                                                                        <label for="startdate">
                                                                            <h6>Start date</h6>
                                                                        </label>
                                                                        <h4 id="datetime_startdate"><?php echo e(\Carbon\Carbon::parse($leave_application->start_date)->format('M d, Y')); ?> (<?php echo e($leave_application->start_of_date_parts->day_part_title); ?>)</h4>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <label for="enddate">
                                                                            <h6>End date</h6>
                                                                        </label>
                                                                        <h4 id="datetime_enddate"><?php echo e(\Carbon\Carbon::parse($leave_application->end_date)->format('M d, Y')); ?> (<?php echo e($leave_application->end_of_date_parts->day_part_title); ?>)</h4>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <label for="enddate">
                                                                            <h6>Date filed</h6>
                                                                        </label>
                                                                        <h4><?php echo e(\Carbon\Carbon::parse($leave_application->created_at)->format('M d, Y - h:i:s A')); ?></h4>
                                                                    </div>
                                                                </div>
                                                                <div class="row mt-4">
                                                                    <div class="col">
                                                                        <label for="employee">
                                                                            <h6 class="">Application by</h6>
                                                                        </label>
                                                                        <h5>
                                                                            <?php echo e(optional($leave_application->employees->users)->first_name); ?>

                                                                            <?php echo e(optional($leave_application->employees->users)->last_name); ?>

                                                                            <?php echo e(optional($leave_application->employees->users->suffixes)->suffix_title); ?>

                                                                        </h5>
                                                                    </div>
                                                                </div>
                                                                <div class="row mt-2">
                                                                    <div class="col">
                                                                        <?php if(!empty($leave_application->attachment)): ?>
                                                                            <a target="_blank" href="<?php echo e(asset('storage/images/'.$leave_application->attachment)); ?>">View Attachment</a>
                                                                        <?php else: ?>
                                                                            <label for="">No Attachment</label>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="row mt-2">
                                                                    <div class="col">
                                                                        <label class="" for="reason">
                                                                            <h6 class="">Reason / Note</h6>
                                                                        </label>
                                                                        <?php $__currentLoopData = $leave_application_notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_application_note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($leave_application_note->leave_application_reference == $leave_application->reference_number): ?>
                                                                                <textarea class="form-control" disabled><?php echo e($leave_application_note->reason_note); ?></textarea>
                                                                                <?php if($leave_application_note->author_id != null): ?>
                                                                                    <p> - <?php echo e(optional($leave_application_note->users)->first_name); ?> <?php echo e(optional($leave_application_note->users)->last_name); ?> at <?php echo e($leave_application_note->created_at); ?></p>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col">
                                                                        <label class="" for="update">
                                                                            <?php if($leave_application->status_id == 'sta-1001'): ?>
                                                                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updatedetailsModal<?php echo e($leave_application->reference_number); ?>">
                                                                                    Add note / comment
                                                                                </button>
                                                                            <?php endif; ?>
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="row mt-2">
                                                                    <div class="col">
                                                                        <label class="" for="status">
                                                                            <h6 class="">Status</h6>
                                                                        </label>
                                                                        <?php if($leave_application->status_id == 'sta-1001'): ?>
                                                                            <?php $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($leave_approval->leave_application_reference == $leave_application->reference_number): ?>
                                                                                    <p class="bg-secondary text-light ps-3"><?php echo e($leave_approval->statuses->status_title); ?> - <?php echo e(optional($leave_approval->approvers)->first_name." ". optional($leave_approval->approvers)->last_name); ?></p>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="<?php echo e(route('employee_leave_rejection',$leave_application->reference_number)); ?>" onsubmit="onClickApprove()">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-danger" data-bs-dismiss="modal">Reject</button>
                                                    </form>
                                                    <form action="<?php echo e(route('employee_leave_approval',$leave_application->reference_number)); ?>" onsubmit="onClickApprove()">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-success" id="submit_button2" data-bs-dismiss="modal">Approve</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                <!-- update details Modal -->
                                    <div class="modal fade" id="updatedetailsModal<?php echo e($leave_application->reference_number); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(route('create_note_employee_leaveapplication',['leave_application_rn'=>$leave_application->reference_number])); ?>" id="form_submit" method="POST" onsubmit="submitButtonDisabled()" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('POST'); ?>
                                                    <div class="modal-body">
                                                        <div class="container-fluid text-start">
                                                            <div class="row">
                                                                <div class="col-lg-4 col-md-12 col-sm-12 bg-pattern-1 text-light text-center justify-content-center align-items-center">
                                                                    <h2></h2>
                                                                </div>
                                                                <div class="col-lg-8 col-md-12 col-sm-12">
                                                                    <div class="row">
                                                                        <div class="col">
                                                                            <label for="employee">
                                                                                <h6 class="">Reference Number</h6>
                                                                            </label>
                                                                            <h4><?php echo e($leave_application->reference_number); ?></h4>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col">
                                                                            <label class="" for="leavetype">
                                                                                <h6 class="">Leave Type</h6>
                                                                            </label>
                                                                            <input type="text" class="form-control text-start" value="<?php echo e(optional($leave_application->leavetypes)->leave_type_title); ?>" disabled>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row ">
                                                                        <div class="col-6">
                                                                            <label for="startdate">
                                                                                <h6>Start date</h6>
                                                                            </label>
                                                                            <input type="date" class="form-control" id="startdate" name="startdate" placeholder="" value="<?php echo e(\Carbon\Carbon::parse($leave_application->start_date)->format('Y-m-d')); ?>" disabled>
                                                                        </div>
                                                                        <div class="col-6">
                                                                            <label for="enddate">
                                                                                <h6>End date</h6>
                                                                            </label>
                                                                            <input type="date" class="form-control" id="enddate" name="enddate" placeholder="" value="<?php echo e(\Carbon\Carbon::parse($leave_application->end_date)->format('Y-m-d')); ?>" disabled>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-6">
                                                                            <label for="startdate">
                                                                                <h6><?php echo e($leave_application->start_of_date_parts->day_part_description); ?></h6>
                                                                            </label>
                                                                        </div>
                                                                        <div class="col-6">
                                                                            <label for="enddate">
                                                                                <h6><?php echo e($leave_application->end_of_date_parts->day_part_description); ?></h6>
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col">
                                                                            <label for="">Duration (days)</label>
                                                                            <input type="text" name="duration" placeholder="" id="duration_input_update" class="form-control" value="<?php echo e($leave_application->duration); ?>" disabled/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mt-4">
                                                                        <div class="col">
                                                                            <label for="employee">
                                                                                <h6 class="">Employee</h6>
                                                                            </label>
                                                                            <h5><?php echo e(optional($leave_application->employees->users)->first_name); ?> <?php echo e(optional($leave_application->employees->users)->last_name); ?> <?php echo e(optional($leave_application->employees->users->suffixes)->suffix_title); ?></h5>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mt-2">
                                                                        <div class="col">
                                                                            <?php if(!empty($leave_application->attachment)): ?>
                                                                                <a target="_blank" href="<?php echo e(asset('storage/images/'.$leave_application->attachment)); ?>">View Attachment</a>
                                                                            <?php else: ?>
                                                                                <i>No Attachment</i>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mt-2">
                                                                        <div class="col">
                                                                            <label class="" for="reason">
                                                                                <h6 class="">Reason / Note</h6>
                                                                            </label>
                                                                            <?php $__currentLoopData = $leave_application_notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_application_note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($leave_application_note->leave_application_reference == $leave_application->reference_number): ?>
                                                                                    <textarea class="form-control" disabled><?php echo e($leave_application_note->reason_note); ?></textarea>
                                                                                    <?php if($leave_application_note->author_id != null): ?>
                                                                                        <p> - <?php echo e(optional($leave_application_note->users)->first_name); ?> <?php echo e(optional($leave_application_note->users)->last_name); ?> at <?php echo e($leave_application_note->created_at); ?></p>
                                                                                    <?php endif; ?>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mt-1">
                                                                        <div class="col">
                                                                            <textarea class="form-control" id="reason" name="reason" placeholder="add note / comment" rows="5"></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mt-2">
                                                                        <div class="col">
                                                                            <label class="" for="status">
                                                                                <h6 class="">Status</h6>
                                                                            </label>
                                                                            <?php if($leave_application->status_id == 'sta-1001'): ?>
                                                                                <p class="bg-secondary text-light ps-3"><?php echo e($leave_application->statuses->status_title); ?></p>
                                                                            <?php elseif($leave_application->status_id == 'sta-1002'): ?>
                                                                                <p class="bg-success text-light ps-3"><?php echo e($leave_application->statuses->status_title); ?></p>
                                                                            <?php elseif($leave_application->status_id == 'sta-1003'): ?>
                                                                                <p class="bg-success text-light ps-3"><?php echo e($leave_application->statuses->status_title); ?></p>
                                                                            <?php elseif($leave_application->status_id == 'sta-1004'): ?>
                                                                                <p class="bg-danger text-light ps-3"><?php echo e($leave_application->statuses->status_title); ?></p>
                                                                            <?php elseif($leave_application->status_id == 'sta-1005'): ?>
                                                                                <p class="bg-danger text-light ps-3"><?php echo e($leave_application->statuses->status_title); ?></p>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-transparent" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit1" class="btn btn-success" data-bs-dismiss="modal" onclick="onClickApprove()">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td>
                                    <div class="row align-items-center justify-content-center mt-3">
                                        <div class="col text-center">
                                            <h2>No leave application available!</h2>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="mt-5">
                    <ul class="pagination justify-content-center align-items-center">
                        <?php echo $leave_applications->links('pagination::bootstrap-5'); ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.employee.leave_management.for_approval', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/employee/leave_management/for_approval_list.blade.php ENDPATH**/ ?>