
<?php $__env->startSection('title','Area of Assignments'); ?>
<?php $__env->startSection('sidebar_settings_active','active'); ?>
<?php $__env->startSection('content'); ?>

settings

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/admin/system_settings.blade.php ENDPATH**/ ?>