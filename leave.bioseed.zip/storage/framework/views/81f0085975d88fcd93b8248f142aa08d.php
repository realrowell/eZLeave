<?php $__env->startSection('list_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>



<div class="container-fluid">
    <div class="row">
        <div class="table-responsive">
            <div class="table-wrapper">
                <table id="data_table" class="table table-bordered table-hover bg-light shadow">
                    <thead class="bg-success text-light border-light">
                        <tr>
                            <th>Department</th>
                            <th class="text-end pe-5">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($department->department_title); ?></td>
                                <td class="text-end pe-5">
                                    <a type="button" href="#" class="btn btn-sm btn-primary">
                                        View
                                    </a>
                                    <a href="#" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#update_department<?php echo e($department->id); ?>" title="Update">
                                        Update
                                    </a>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#delete_department_<?php echo e($department->id); ?>" title="Delete">
                                        Delete
                                    </button>
                                </td>
                            </tr>
                            <!-- Update Department Modal -->
                                <div class="modal fade" id="update_department<?php echo e($department->id); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?php echo e(route('admin_update_department',['id'=>$department->id])); ?>" method="PUT" onsubmit="submitButtonDisabled()">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="staticBackdropLabel">Update Department</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="container-fluid text-start">
                                                        <div class="row mt-2 mb-3" >
                                                            <div class="col">
                                                                <label for="department_title"><h6 class="profile-title">Deparment name</h6></label>
                                                                <input type="text" class="form-control" id="department_title" name="department_title" placeholder="<?php echo e($department->department_title); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Discard</button>
                                                    <button id="submit_button" type="submit" class="btn btn-success" >Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            
                            <!-- Delete Department Modal -->
                                <div class="modal fade " id="delete_department_<?php echo e($department->id); ?>" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?php echo e(route('admin_delete_department',['id'=>$department->id])); ?>" method="PUT" onsubmit="submitButtonDisabled()">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="staticBackdropLabel">Delete department</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="container-fluid text-start">
                                                        <div class="row mt-2 mb-3" >
                                                            <div class="col">
                                                                <label for="department_title"><h6 class="profile-title">Are you sure you want to delete this?</h6></label>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-outlined" data-bs-dismiss="modal">Discard</button>
                                                    <button id="submit_button2" type="submit" class="btn btn-danger" >Confirm</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col">
                        <div class="mt-2 mb-5">
                            <ul class="pagination justify-content-center align-items-center">
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.admin.organization.departments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/admin/organization/departments_list.blade.php ENDPATH**/ ?>