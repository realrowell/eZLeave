<?php $__env->startSection('list_view_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>

<div class="row">
    <div class="spinner-border text-primary" id="loading_spinner_approve" role="status" style="display: none;">
        <span class="visually-hidden" >Loading...</span>
    </div>
    <div id="table_container">
        <div class="table-wrapper">
            <table id="data_table" class="table table-sm compact table-bordered table-hover bg-light shadow">
                <thead class="bg-success text-light border-light">
                    <tr>
                        <th>Reference Number</th>
                        <th>Employee</th>
                        <th>Leave Type</th>
                        <th>Start date</th>
                        <th>End date</th>
                        <th>Duration (days)</th>
                        <th>Approved at</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $leave_approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($leave_approval->leave_applications->reference_number); ?></td>
                            <td id="table_reports_to">
                                <?php if(!empty($leave_approval->leave_applications->employees)): ?>
                                    <?php echo e(optional($leave_approval->leave_applications->employees->users)->first_name); ?>

                                    <?php echo e(optional($leave_approval->leave_applications->employees->users)->middle_name); ?>

                                    <?php echo e(optional($leave_approval->leave_applications->employees->users)->last_name); ?>

                                <?php else: ?>
                                    Not Available
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(optional($leave_approval->leave_applications->leavetypes)->leave_type_title); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($leave_approval->leave_applications->start_date)->format('M d, Y')); ?> - <?php echo e($leave_approval->leave_applications->start_of_date_parts->day_part_title); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($leave_approval->leave_applications->end_date)->format('M d, Y')); ?> - <?php echo e($leave_approval->leave_applications->end_of_date_parts->day_part_title); ?></td>
                            <td><?php echo e($leave_approval->leave_applications->duration); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($leave_approval->created_at)->format('M d, Y - h:i:sA')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col">
                <div class="mt-2 mb-5">
                    <ul class="pagination justify-content-center align-items-center">
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.employee.leave_management.approval_history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/employee/leave_management/approval_history_list.blade.php ENDPATH**/ ?>