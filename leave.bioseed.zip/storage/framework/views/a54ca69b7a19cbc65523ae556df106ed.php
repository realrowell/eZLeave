<?php $__env->startSection('title','Leave Menu'); ?>
<?php $__env->startSection('sidebar_leave_management_active','active'); ?>
<?php $__env->startSection('sidebar_leave_management_active_custom','active_custom'); ?>
<?php $__env->startSection('custom_active_leave_icon','var(--accent-color)'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid mb-4 pb-5" id="profile_body">
    <div class="row">
        <div class="col mt-2">
          <h3>Leave Management Maintenance</h3>
        </div>
    </div>
    <div class="row">
        <div class="row justify-content-center align-items-start g-4">
            <div class="col-custom col-lg-5 col-md-5 col-sm-12">
                <a class="text-dark" href="<?php echo e(route('admin.leave.types')); ?>">
                    <div class="card shadow card-menu border-0">
                        <div class="card-body text-center m-3">
                            <i class='bx bx-duplicate' style="font-size: 100px;"></i>
                            <h5 class="card-title mt-3">Leave Types</h5>
                        </div>
                    </div>
                </a>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/admin/leave_management/leave_management_menu.blade.php ENDPATH**/ ?>