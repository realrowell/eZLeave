<?php $__env->startSection('title','Employee Management'); ?>
<?php $__env->startSection('sidebar_employee_management_active','active'); ?>
<?php $__env->startSection('content'); ?>


<div class="container-fluid mb-4 pb-5" id="profile_body">
    <div class="row mb-3">
        <div class="col-sm-12 col-md-4 col-lg-6 mt-2">
            <h3><a href="<?php echo e(route('hrstaff_employees_grid')); ?>" class="text-dark">Employee Management</a> /
                <a href="#" class="text-dark">Profile</a>
            </h3>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-6 justify-content-end align-items-end text-end mt-2">

        </div>
    </div>
    <div class="row justify-content-center align-items-start d-flex gap-2 mb-5">
        <div class="col-lg-3 col-md-3 col-sm-10 bg-light align-self-stretch shadow bg-gradient-primary m-2" style="min-height: 10rem">
            <div class="row">
                <div class="col text-center p-5">
                    <div class="row justify-content-center align-items-start">
                        <div class="profile-photo-box align-items-start pt-3 pb-4">
                            <img class="profile-photo" src="/img/dummy_profile.jpg" alt="profile photo">
                        </div>
                    </div>
                    <h4 class="text-light "><?php echo e($user->first_name); ?> <?php echo e($user->middle_name); ?> <?php echo e($user->last_name); ?> <?php echo e(optional($user->suffixes)->suffix_title); ?></h4>
                    <div class="text-light">
                        
                        <?php if($user->status_id == 'sta-2001'): ?>
                            <p class="card-desc badge bg-success"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2002'): ?>
                            <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2003'): ?>
                            <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2004'): ?>
                            <p class="card-desc badge bg-danger"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2002'): ?>
                            <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-10">
            <div class="row bg-light mt-2 z-1 p-1 ps-4 m-1 shadow justify-content-lg-center justify-content-md-start justify-content-sm-center justify-content-center">
                <div class="row justify-content-start align-items-start text-start">
                    <div class="col">
                        <a href="<?php echo e(route('admin_visit_employee_view',['username'=>$user->user_name])); ?>" class="ms-1 me-1 p-2 custom-primary-button">
                            Profile
                        </a>
                        <a href="<?php echo e(route('visit_employee_leave_ms_view',['username'=>$user->user_name])); ?>" class="ms-1 me-1 p-2 custom-primary-button bg-selected-warning">
                            Leave MS
                        </a>
                        <div class="btn-group me-1 ">
                            <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Fiscal Year:
                                <?php if(Request()->fiscal_year == null): ?>
                                    <?php echo e($current_fiscal_year->fiscal_year_title); ?>

                                <?php else: ?>
                                    <?php $__currentLoopData = $fiscal_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fiscal_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $fiscal_year->id == Request()->fiscal_year): ?>
                                            <?php echo e($fiscal_year->fiscal_year_title); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </button>
                            <ul class="dropdown-menu">
                              <?php $__currentLoopData = $fiscal_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fiscal_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><a class="dropdown-item" href="<?php echo e(route('hrstaff_fy_leave_credits',['fiscal_year'=>$fiscal_year->id])); ?>"><?php echo e($fiscal_year->fiscal_year_title); ?></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col text-end align-items-end">
                        <div class="btn-group me-1"  role="group">
                            <a href="#" class="btn btn-sm btn-outline-primary">Export PDF</a>
                            <a href="#" class="btn btn-sm btn-primary">Export CSV</a>
                        </div>
                    </div>
                </div>
                
                    <div class="row">
                        <div class="row mt-4 d-grid gap-1 mx-auto justify-content-center text-center">
                            <div class="col">
                                <h3>Leave Monitoring</h3>
                            </div>
                            <div class="col">
                                <h3><?php echo e(\Carbon\Carbon::now()->format('M d, Y')); ?></h3>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="row mt-2 mb-2" >
                                <div class="col-12">
                                    <h6 class="profile-title">Full Name</h6>
                                    <h6 class="profile-title-value"><?php echo e($user->first_name); ?> <?php echo e($user->middle_name); ?> <?php echo e($user->last_name); ?> <?php echo e(optional($user->suffixes)->suffix_title); ?></h6>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <h6 class="profile-title">Position</h6>
                                    <h6 class="profile-title-value"><?php echo e(optional(optional($user->employees->employee_positions)->positions)->position_description); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6 class="profile-title">Sub-department</h6>
                                    <h6 class="profile-title-value"><?php echo e(optional(optional(optional($user->employees->employee_positions)->positions)->subdepartments)->sub_department_title); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6 class="profile-title">Department</h6>
                                    <h6 class="profile-title-value"><?php echo e(optional(optional(optional(optional($user->employees->employee_positions)->positions)->subdepartments)->departments)->department_title); ?></h6>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <h6 class="profile-title">Date Hired</h6>
                                    <h6 class="profile-title-value"><?php echo e(\Carbon\Carbon::parse(optional($user->employees)->date_hired)->format('M d, Y')); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6 class="profile-title">Length of Service</h6>
                                    <h6 class="profile-title-value">
                                        <?php if($length_of_service > 1.9): ?>
                                            <?php echo e($length_of_service); ?> years
                                        <?php else: ?>
                                            <?php echo e($length_of_service); ?> year
                                        <?php endif; ?>
                                    </h6>
                                </div>
                                <div class="col-4">
                                    <h6 class="profile-title">Employment Status</h6>
                                    <h6 class="profile-title-value"><?php echo e($user->employees->employment_statuses->employment_status_title); ?></h6>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <h6 class="profile-title">Reports to</h6>
                                    <h6 class="profile-title-value"><?php echo e($reports_to); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6 class="profile-title">Second superior</h6>
                                    <h6 class="profile-title-value"><?php echo e($second_reports_to); ?></h6>
                                </div>
                            </div>
                        </div>

                        <div class=" mt-3 row">
                            <hr class="hr" />
                        </div>

                        <div class="mt-3" id="CollapseMenu">
                            <div class="row">
                                <div class="col d-flex gap-3">
                                    <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#LeaveCollapse" aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">
                                        Leave Credit Monitoring
                                    </button>
                                    <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#LogsCollapse" aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">
                                        Logs
                                    </button>
                                    <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#HistoryCollapse" aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">
                                        History
                                    </button>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    
                                        <div class="collapse show multi-collapse" id="LeaveCollapse" data-bs-parent="#CollapseMenu">
                                            <div class="row mt-3 d-grid ">
                                                <div class="col">
                                                    <h4>Leave Credit Monitoring</h4>
                                                </div>
                                            </div>
                                            <div class="row mt-1">
                                                <?php $__currentLoopData = $employee_leavecredits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_leavecredit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="row mt-1 d-grid ">
                                                        <div class="col">
                                                            <h5><i class='bx bx-chevron-right' ></i>  <?php echo e($employee_leavecredit->leavetypes->leave_type_title); ?></h5>
                                                        </div>
                                                    </div>
                                                    <div class="table-responsive">
                                                        <div class="table-wrapper">
                                                            <table id="data_table" class="table table-hover table-sm table-bordered bg-light">
                                                                <thead role="rowgroup">
                                                                    <tr class="bg-primary text-light border-light" style="font-size: 0.9rem">
                                                                        <th>FROM</th>
                                                                        <th>TO</th>
                                                                        <th>DAYS</th>
                                                                        <th>BALANCE</th>
                                                                        <th>NOTE</th>
                                                                        <th>CREATED</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $employee_leavecredit_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_leavecredit_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr role="rowgroup">
                                                                            <?php if(optional($employee_leavecredit_log->employee_leave_credits)->leave_type_id == $employee_leavecredit->leave_type_id): ?>
                                                                                <?php $__currentLoopData = $employee_leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_leave_application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if(optional($employee_leavecredit_log->leave_application_rn)!=null): ?>
                                                                                        <?php if($employee_leavecredit_log->leave_application_rn == $employee_leave_application->reference_number): ?>
                                                                                            <td class=" text-break" style="width: 15%">
                                                                                                <?php echo e(\Carbon\Carbon::parse(optional($employee_leavecredit_log->leave_applications)->start_date)->format('M d, Y')); ?> - <?php echo e(optional(optional($employee_leavecredit_log->leave_applications)->start_of_date_parts)->day_part_title); ?>

                                                                                            </td>
                                                                                            <td class=" text-break" style="width: 15%">
                                                                                                <?php echo e(\Carbon\Carbon::parse(optional($employee_leavecredit_log->leave_applications)->end_date)->format('M d, Y')); ?> - <?php echo e(optional(optional($employee_leavecredit_log->leave_applications)->end_of_date_parts)->day_part_title); ?>

                                                                                            </td>
                                                                                            <td class=" text-break" style="width: 10%"><?php echo e($employee_leavecredit_log->leave_days_credit); ?></td>
                                                                                            <td class=" text-break" style="width: 10%"><?php echo e($employee_leavecredit_log->employee_leave_credits->leave_days_credit); ?></td>
                                                                                            <td class=" text-break" style="width: 35%"><?php echo e($employee_leavecredit_log->reason_note); ?></td>
                                                                                            <td class=" text-break" style="width: 15%"><?php echo e(optional($employee_leavecredit_log->leave_applications)->created_at); ?></td>
                                                                                        <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    
                                    
                                        <div class="collapse multi-collapse" id="LogsCollapse" data-bs-parent="#CollapseMenu">
                                            <div class="row mt-3 d-grid ">
                                                <div class="col">
                                                    <h4>Leave Credits Log</h4>
                                                </div>
                                            </div>
                                            <div class="row mt-1">
                                                <?php $__currentLoopData = $employee_leavecredits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_leavecredit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="row mt-1 d-grid ">
                                                        <div class="col">
                                                            <h5><i class='bx bx-chevron-right' ></i>  <?php echo e($employee_leavecredit->leavetypes->leave_type_title); ?></h5>
                                                        </div>
                                                    </div>
                                                    <div class="table-responsive">
                                                        <div class="table-wrapper">
                                                            <table id="" class="table table-hover table-sm table-bordered bg-light">
                                                                <thead role="rowgroup">
                                                                    <tr class="bg-primary text-light border-light" style="font-size: 0.9rem">
                                                                        <th>Leave Type</th>
                                                                        <th>Credits</th>
                                                                        <th>Adjustment</th>
                                                                        <th>Note</th>
                                                                        <th>Created at</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $employee_leavecredit_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_leavecredit_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr role="rowgroup">
                                                                            <?php if(optional($employee_leavecredit_log->employee_leave_credits)->leave_type_id == $employee_leavecredit->leave_type_id): ?>
                                                                                <td class="col-2 text-break"><?php echo e($employee_leavecredit_log->employee_leave_credits->leavetypes->leave_type_title); ?></td>
                                                                                <td class="col-1 text-break"><?php echo e($employee_leavecredit_log->employee_leave_credits->leave_days_credit); ?></td>
                                                                                <td class="col-1 text-break"><?php echo e($employee_leavecredit_log->leave_days_credit); ?></td>
                                                                                <td class="col-4 text-break"><?php echo e($employee_leavecredit_log->reason_note); ?></td>
                                                                                <td class="col-2 text-break"><?php echo e($employee_leavecredit_log->created_at); ?></td>
                                                                            <?php endif; ?>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                            <div class="row mt-3">
                                                <hr class="hr" />
                                            </div>

                                            <div class="row mt-4 d-grid ">
                                                <div class="col">
                                                    <h4>Leave Applcations Log</h4>
                                                </div>
                                            </div>
                                            <div class="row mt-1">
                                                <div class="table-responsive">
                                                    <div class="table-wrapper">
                                                        <table id=" " class="table table-hover table-sm table-bordered bg-light">
                                                            <thead role="rowgroup">
                                                                <tr class="bg-primary text-light border-light" style="font-size: 0.9rem">
                                                                    <th>Reference #</th>
                                                                    <th>Leave Type</th>
                                                                    <th>Start date</th>
                                                                    <th>End date</th>
                                                                    <th>Duration</th>
                                                                    <th>Attachment</th>
                                                                    <th>Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="">
                                                                <?php $__currentLoopData = $employee_leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_leave_application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr role="rowgroup card-body">
                                                                        <td class="text-break text-dark"><a class="custom-bg-primary-hover text-light-hover" href="<?php echo e(route('hr_leave_details_page',['leave_application_rn'=>$employee_leave_application->reference_number])); ?>" target="_blank"><?php echo e($employee_leave_application->reference_number); ?></a> </td>
                                                                        <td class="text-break"><?php echo e($employee_leave_application->leavetypes->leave_type_title); ?></td>
                                                                        <td class="text-break"><?php echo e(\Carbon\Carbon::parse($employee_leave_application->start_date)->format('M d, Y')); ?> - <?php echo e($employee_leave_application->start_of_date_parts->day_part_title); ?></td>
                                                                        <td class="text-break"><?php echo e(\Carbon\Carbon::parse($employee_leave_application->end_date)->format('M d, Y')); ?> - <?php echo e($employee_leave_application->end_of_date_parts->day_part_title); ?></td>
                                                                        <td class="text-break"><?php echo e($employee_leave_application->duration); ?></td>
                                                                        <td class="text-break">
                                                                            <?php if(!empty($employee_leave_application->attachment)): ?>
                                                                                <a target="_blank" href="<?php echo e(asset('storage/images/'.$employee_leave_application->attachment)); ?>">View Attachment</a>
                                                                            <?php else: ?>
                                                                                <label for="">No Attachment</label>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td class="text-break">
                                                                            <?php if($employee_leave_application->status_id == 'sta-1001'): ?>
                                                                                <span class="badge bg-secondary rounded-pill"><?php echo e($employee_leave_application->statuses->status_title); ?></span>
                                                                            <?php elseif($employee_leave_application->status_id == 'sta-1002'): ?>
                                                                                <span class="badge bg-success rounded-pill"><?php echo e($employee_leave_application->statuses->status_title); ?></span>
                                                                            <?php elseif($employee_leave_application->status_id == 'sta-1003'): ?>
                                                                                <span class="badge bg-secondary rounded-pill"><?php echo e($employee_leave_application->statuses->status_title); ?></span>
                                                                            <?php elseif($employee_leave_application->status_id == 'sta-1004'): ?>
                                                                                <span class="badge bg-danger rounded-pill"><?php echo e($employee_leave_application->statuses->status_title); ?></span>
                                                                            <?php elseif($employee_leave_application->status_id == 'sta-1005'): ?>
                                                                                <span class="badge text-dark bg-warning rounded-pill"><?php echo e($employee_leave_application->statuses->status_title); ?></span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                    
                                        <div class="collapse multi-collapse" id="HistoryCollapse" data-bs-parent="#CollapseMenu">
                                            <div class="row mt-3 d-grid ">
                                                <div class="col">
                                                    <h4>Leave Credit History</h4>
                                                </div>
                                            </div>
                                            <div class="row mt-1">
                                                
                                                <div class="table-responsive">
                                                    <div class="table-wrapper">
                                                        <table id="" class="table table-hover table-sm table-bordered bg-light">
                                                            <thead role="rowgroup">
                                                                <tr class="bg-primary text-light border-light" style="font-size: 0.9rem">
                                                                    <th>Year</th>
                                                                    <th>Leave Type</th>
                                                                    <th>Credits Balance</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $employee_leavecredit_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_leavecredit_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($employee_leavecredit_history->fiscal_years->fiscal_year_title); ?></td>
                                                                        <td><?php echo e($employee_leavecredit_history->leavetypes->leave_type_title); ?></td>
                                                                        <td><?php echo e($employee_leavecredit_history->leave_days_credit); ?></td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/admin/account_management/visit_employee_leave_view.blade.php ENDPATH**/ ?>