<?php $__env->startSection('list_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>



<div class="row">
    <div>
        <div class="table-responsive">
            <div class="table-wrapper">
                <table id="data_table" class="table table-bordered table-hover bg-light ">
                    <thead class="bg-success text-light border-light">
                        <tr>
                            <th>Full Name</th>
                            <th>Position</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Sub-department</th>
                            <th>Department</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="row">
                                    <div class="col">
                                        <?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?> <?php echo e($user->middle_name); ?> <?php echo e(optional($user->suffixes)->suffix_title); ?>

                                    </div>
                                </div>
                            </td>
                            <td><?php echo e(optional(optional($user->employees->employee_positions)->positions)->position_description); ?></td>
                            <td><?php echo e($user->user_name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->employees->genders->gender_title); ?></td>
                            <td><?php echo e(optional(optional(optional($user->employees->employee_positions)->positions)->subdepartments)->sub_department_title); ?></td>
                            <td><?php echo e(optional(optional(optional(optional($user->employees->employee_positions)->positions)->subdepartments)->departments)->department_title); ?></td>
                            <td class="d-flex gap-2">
                                
                                <button class="btn btn-primary btn-sm rounded-3 " type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class='bx bx-dots-vertical-rounded' ></i>
                                </button>
                                <ul class="dropdown-menu shadow-lg dropdown-menu-dark text-light">
                                    <li>
                                        <a href="<?php echo e(route('user_profile',['username' => $user->user_name])); ?>" class="dropdown-item pb-2">
                                            <i class='bx bxs-user me-2'></i>Profile
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('user_profile_leave',['username' => $user->user_name])); ?>" class="dropdown-item pb-2">
                                            <i class='bx bx-calendar me-2' ></i>Leave-MS
                                        </a>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="mt-5">
                <ul class="pagination justify-content-center align-items-center">
                    
                </ul>
            </div>
        </div>
    </div>
</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.hr_staff.employee_management.employees', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave.bioseed\resources\views/profiles/hr_staff/employee_management/employees_list_view.blade.php ENDPATH**/ ?>