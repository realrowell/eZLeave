
<?php $__env->startSection('title','HOME'); ?>
<?php $__env->startSection('content'); ?>

<section id="main">
    <div id="home_content" class="" style="">
        <div class="container text-start">
            <div class="row align-items-start">
                <div class="col-md-6 col-lg-6" style="">
                    
                </div>
                
                <div id="card_login_form" class="col-md-6 col-lg-6 card_login_form" style=" padding-top:10vh;">
                    <div class="card-body" style="">
                        <div class="container-fluid text-center">
                            <div class="row justify-content-center">
                                <img id="logo" class="" src="/img/bioseed_logo.png" alt="bioseed_logo" style="width: 100px">
                                <h2 class="card-title">Welcome Back Admin!</h2>
                            </div>
                            <div class="row mt-4 card-body">
                                <form method="POST" action="/admin_login" onsubmit="changeClass()">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <?php if(session('error')): ?>
                                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="email" class="form-label text-start"><?php echo e(__('Email Address')); ?></label>
            
                                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
            
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
            
                                    <div class="row mb-3">
                                        <label for="password" class="form-label text-start"><?php echo e(__('Password')); ?></label>
                                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
            
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
            
                                    <div class="row mb-2 mt-5">
                                        <button id="login_submit" type="submit" class="btn btn-success">
                                            <?php echo e(__('Login')); ?>

                                        </button>
        
                                        <div class="row mt-3">
                                            <?php if(Route::has('password.request')): ?>
                                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                                    <?php echo e(__('Forgot Your Password?')); ?>

                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <br>
                    </div>
                </div>
            </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software Projects\Laravel Web App\Leave Management System\BioseedLeaveManagementSystem\resources\views/profiles/admin/admin_login.blade.php ENDPATH**/ ?>