<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('sidebar_dashboard_active','active'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid mb-4 pb-5" id="profile_body">
  <div class="row">
    <div class="col mt-2">
      <h3>Dashboard</h3>
    </div>
  </div>
  <div class="row">
    <div class="row justify-content-center align-items-start g-2">
      <div class="col-md bg-light border pt-2 ps-2 pb-5 me-2 shadow border-bottom-0 border-end-0 border-top-0 border-warning border-5">
        <div class="row ">
          <div class="col"><h5>Account Management</h5></div>
          <div class="col d-flex justify-content-end pe-4">
            <a href="/" class="btn-sm btn-primary">see all</a>
          </div>
        </div>
        <div class="container-fluid">
          <div class="row justify-content-center align-items-center text-center g-2 mt-3">
            <a href="#" class="col-md text-dark">
              <span id="approval_numbers" class="col"><?php echo e($users_count); ?></span>
                <div class="row">
                  <span class="col">Number of Accounts</span>
                </div>
            </a>
            <a href="#" class="col-md text-dark">
                <span id="approval_numbers" class="col"><?php echo e($users_count_active); ?></span>
                  <div class="row">
                    <span class="col">Active Accounts</span>
                  </div>
              </a>
              <a href="#" class="col-md text-dark">
                <span id="approval_numbers" class="col"><?php echo e($user_count_admin); ?></span>
                  <div class="row">
                    <span class="col">Admin Accounts</span>
                  </div>
              </a>
          </div>
        </div>
      </div>
      <div class="col-md bg-light border pt-2 ps-2 pb-5 ms-2 shadow border-bottom-0 border-end-0 border-top-0 border-warning border-5">
        <div class="row ">
          <div class="col"><h5>Login Logs</h5></div>
          <div class="col d-flex justify-content-end pe-4">
            <a href="<?php echo e(route('admin_login_logs')); ?>" class="btn-sm btn-primary">see all</a>
          </div>
        </div>
        <?php $__currentLoopData = $login_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $login_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row m-2">
            <div class="col"><i><?php echo e($login_log->users->first_name." ".$login_log->users->middle_name." ".$login_log->users->last_name); ?></i></div>
            <div class="col"><?php echo e($login_log->date_time); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BioseedLeaveManagementSystem\resources\views/profiles/admin/admin_dashboard.blade.php ENDPATH**/ ?>