<?php $__env->startSection('title','Employee Management'); ?>
<?php $__env->startSection('sidebar_employee_management_active','active'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid mb-4 pb-5" id="profile_body">
    <div class="row mb-3">
        <div class="col-sm-12 col-md-4 col-lg-6 mt-2">
            <h3><a href="<?php echo e(route('hrstaff_employees_grid')); ?>" class="text-dark">Employee Management</a> /
                <a href="#" class="text-dark">Profile</a>
            </h3>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-6 justify-content-end align-items-end text-end mt-2">

        </div>
    </div>
    <div class="row justify-content-center align-items-start d-flex gap-2 mb-5">
        <div class="col-lg-3 col-md-3 col-sm-10 bg-light align-self-stretch shadow bg-gradient-primary m-2" >

            <div class="row">
                <div class="col text-center p-5">
                    <div class="row justify-content-center align-items-start">
                        <div class="profile-photo-box align-items-start pt-3 pb-4">
                            <?php if($profile_photo == null): ?>
                                <img class="profile-photo" src="/img/dummy_profile.jpg" alt="profile photo">
                            <?php else: ?>
                                <img class="profile-photo" src="<?php echo e(asset('storage/images/profile_photos/'.$profile_photo->profile_photo)); ?>" alt="profile photo">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-grid gap-2 col-12 mx-auto mb-3">
                        
                        <div class="form-control form">
                            <form action="<?php echo e(route('admin_update_profile_photo',['username'=>$user->user_name])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <label for="profile_photo" class="form-label mt-3">Upload Profile Photo</label>
                                <input class="form-control" type="file" id="profile_photo" name="profile_photo">
                                <button class="form-control btn btn-sm btn-primary mt-4 mb-3" type="submit">Upload</button>
                            </form>
                        </div>
                    </div>
                    <h4 class="text-light text-shadow-1"><?php echo e($user->first_name); ?> <?php echo e($user->middle_name); ?> <?php echo e($user->last_name); ?> <?php echo e(optional($user->suffixes)->suffix_title); ?></h4>
                    <div class="text-light">
                        <?php if($user->status_id == 'sta-2001'): ?>
                            <p class="card-desc badge bg-success"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2002'): ?>
                            <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2003'): ?>
                            <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2004'): ?>
                            <p class="card-desc badge bg-danger"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php elseif($user->status_id == 'sta-2002'): ?>
                            <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-10">
            <div class="row bg-light mt-2 z-1 p-1 ps-4 m-1 shadow">
                <div class="row justify-content-start align-items-start text-start">
                    <div class="col">
                        <a href="<?php echo e(route('user_profile',['username'=>$user->user_name])); ?>" class="ms-1 me-1 p-2 custom-primary-button bg-selected-warning">
                            Profile
                        </a>
                        <a href="<?php echo e(route('user_profile_leave',['username'=>$user->user_name])); ?>" class="ms-1 me-1 p-2 custom-primary-button <?php echo $__env->yieldContent('grid_active'); ?> ">
                            Leave MS
                        </a>
                    </div>
                </div>
                
                <form action="<?php echo e(route('admin_update_employee',['user_id'=>$user->id,'employee_id'=>$user->employees->id])); ?>" method="POST" onsubmit="submitButtonDisabled()">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <div class="row mt-5">
                            <div class="col-lg-4 col-md-3 col-sm-12">
                                <h3>Employee details</h3>
                            </div>
                            <div class="col-lg-8 col-md-9 col-sm-12">
                                <div class="text-end d-flex gap-3 justify-content-end">
                                    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger">Discard Changes</a>
                                    <button id="submit_button1" type="submit" class="btn btn-success">Save Changes</button>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col">
                                <div class="row mt-2 mb-1" >
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">First name</h6>
                                        <input type="text" class="form-control" id="first_name" name="firstname" value="<?php echo e($user->first_name); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Middle name</h6>
                                        <input type="text" class="form-control" id="middle_name" name="middlename" value="<?php echo e($user->middle_name); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Last name</h6>
                                        <input type="text" class="form-control" id="last_name" name="lastname" value="<?php echo e($user->last_name); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Suffix</h6>
                                        <select class="form-control" id="suffix" name="suffix">
                                            <?php if($user->suffix_id == null): ?>
                                                <option selected value="">N/A</option>
                                                <?php $__currentLoopData = $suffixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suffix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($suffix->id); ?>"><?php echo e($suffix->suffix_title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option selected value="<?php echo e(null); ?>">remove</option>
                                                <option selected value="<?php echo e($user->suffix_id); ?>"><?php echo e(optional($user->suffixes)->suffix_title); ?></option>
                                                <?php $__currentLoopData = $suffixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suffix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($suffix->id != $user->suffix_id): ?>
                                                        <option value="<?php echo e($suffix->id); ?>"><?php echo e($suffix->suffix_title); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mt-3 mb-1">
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Sex</h6>
                                        <select class="form-control" id="gender" name="gender">
                                            <option selected value="<?php echo e($user->employees->gender_id); ?>"><?php echo e(optional($user->employees->genders)->gender_title); ?></option>
                                            <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($user->employees->gender_id != $gender->id): ?>
                                                    <option value="<?php echo e($gender->id); ?>"><?php echo e($gender->gender_title); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Marital Status</h6>
                                        <select class="form-control" id="marital_status" name="marital_status">
                                            <option selected value="<?php echo e($user->employees->marital_status_id); ?>"><?php echo e(optional($user->employees->marital_statuses)->marital_status_title); ?></option>
                                            <?php $__currentLoopData = $marital_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marital_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($marital_status->id != $user->employees->marital_status_id): ?>
                                                    <option value="<?php echo e($marital_status->id); ?>"><?php echo e($marital_status->marital_status_title); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Birth Date</h6>
                                        <input type="date" class="form-control" id="birthdate" name="birthdate" value="<?php echo e(optional($user->employees)->birthdate); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Contact Number</h6>
                                        <input type="text" class="form-control" id="contact_number" name="contact_number" value="<?php echo e(optional($user->employees)->contact_number); ?>">
                                    </div>
                                </div>
                                <div class="row mt-5 mb-5">
                                    <div class="mb-2 col-lg-12 col-md-12 col-sm-12">
                                        <h6 class="profile-title">Address line 1</h6>
                                        <input type="text" class="form-control" id="address_line_1" name="address_line_1" value="<?php echo e(optional($user->employees->employee_addresses)->address_line_1); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">City</h6>
                                        <input type="text" class="form-control" id="address_city" name="address_city" value="<?php echo e(optional($user->employees->employee_addresses)->city); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Province</h6>
                                        <input type="text" class="form-control" id="address_province" name="address_province" value="<?php echo e(optional($user->employees->employee_addresses)->province); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Region</h6>
                                        <input type="text" class="form-control" id="address_region" name="address_region" value="<?php echo e(optional($user->employees->employee_addresses)->region); ?>">
                                    </div>
                                </div>
                                <div class="row mt-5 mb-3">
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Employment status</h6>
                                        <select class="form-control" id="employment_status" name="employment_status">
                                            <option selected value="<?php echo e($user->employees->employment_status_id); ?>"><?php echo e(optional($user->employees->employment_statuses)->employment_status_title); ?></option>
                                            <?php $__currentLoopData = $employment_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($employment_status->id != $user->employees->employment_status_id): ?>
                                                    <option value="<?php echo e($employment_status->id); ?>"><?php echo e($employment_status->employment_status_title); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Date hired</h6>
                                        <input type="date" class="form-control" id="date_hired" name="date_hired" value="<?php echo e(optional($user->employees)->date_hired); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                        <h6 class="profile-title">ID Number</h6>
                                        <input type="text" class="form-control" id="sap_id_number" name="sap_id_number" value="<?php echo e(optional($user->employees)->sap_id_number); ?>">
                                    </div>
                                    <div class="mb-2 col-lg-3 col-md-6 col-sm-12">

                                    </div>
                                </div>
                                <div class="row mt-3 mb-1">
                                    <div class="mb-2 col-lg-6 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Reports to</h6>
                                        <select class="form-control" id="reports_to" name="reports_to">
                                            
                                            <?php if(optional(optional($user->employees->employee_positions)->positions)->position_level_id != 'psl-1001' && optional(optional($user->employees->employee_positions)->positions)->is_hod == true ): ?>
                                                <option selected value="<?php echo e(optional(optional($user->employees)->employee_positions)->reports_to_id); ?>">
                                                    <?php if( !empty(optional($user->employees->employee_positions)->reports_to_id)): ?>
                                                        <?php echo e($reports_to); ?>

                                                    <?php else: ?>
                                                        - Please Select -
                                                    <?php endif; ?>
                                                </option>
                                                <?php $__currentLoopData = $user_reports_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_reports_to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if( $user_reports_to->employees?->employee_positions?->positions?->subdepartments?->department_id == $user->employees->employee_positions?->positions?->subdepartments?->department_id && $user_reports_to->user_name != $user->user_name): ?>
                                                        <?php if( $user_reports_to?->employees?->employee_positions?->positions?->is_hr_manager == false): ?>
                                                            <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                                <?php echo e($user_reports_to->last_name .', '); ?>

                                                                <?php echo e($user_reports_to->first_name); ?>

                                                                <?php echo e($user_reports_to->middle_name); ?>

                                                            </option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if( $user_reports_to->employees?->employee_positions?->positions?->is_hr_manager == true && $user_reports_to?->user_name != $user->employees->employee_positions?->reports_tos?->users?->user_name): ?>
                                                        <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                            <?php echo e($user_reports_to->last_name .', '); ?>

                                                            <?php echo e($user_reports_to->first_name); ?>

                                                            <?php echo e($user_reports_to->middle_name); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                    <?php if( optional(optional(optional($user_reports_to->employees)->employee_positions)->positions)->position_level_id == 'psl-1001'): ?>
                                                        <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                            <?php echo e($user_reports_to->last_name .', '); ?>

                                                            <?php echo e($user_reports_to->first_name); ?>

                                                            <?php echo e($user_reports_to->middle_name); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php elseif( $user->employees?->employee_positions?->positions?->position_level_id == 'psl-1001'): ?>
                                                <option selected value="<?php echo e(optional(optional($user->employees)->employee_positions)->reports_to_id); ?>">
                                                    <?php if( !empty(optional($user->employees->employee_positions)->reports_to_id)): ?>
                                                        <?php echo e($reports_to); ?>

                                                    <?php else: ?>
                                                        - Please Select -
                                                    <?php endif; ?>
                                                </option>
                                                <?php $__currentLoopData = $hrstaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrstaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e(optional($hrstaff)->id); ?>">
                                                        <?php echo e($hrstaff->last_name .', '); ?>

                                                        <?php echo e($hrstaff->first_name); ?>

                                                        <?php echo e($hrstaff->middle_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option selected value="<?php echo e(optional(optional($user->employees)->employee_positions)->reports_to_id); ?>">
                                                    <?php if( !empty(optional($user->employees->employee_positions)->reports_to_id)): ?>
                                                        <?php echo e($reports_to); ?>

                                                    <?php else: ?>
                                                        - Please Select -
                                                    <?php endif; ?>
                                                </option>
                                                <?php $__currentLoopData = $user_reports_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_reports_to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(optional(optional(optional(optional($user_reports_to->employees)->employee_positions)->positions)->subdepartments)->department_id == optional(optional(optional($user->employees->employee_positions)->positions)->subdepartments)->department_id ): ?>
                                                        <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                            <?php echo e($user_reports_to->last_name .', '); ?>

                                                            <?php echo e($user_reports_to->first_name); ?>

                                                            <?php echo e($user_reports_to->middle_name); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mt-1 mb-1">
                                    <div class="mb-2 col-lg-6 col-md-6 col-sm-12">
                                        <h6 class="profile-title">Second superior</h6>
                                        <select class="form-control" id="second_reports_to" name="second_reports_to">
                                            <?php if( $user->employees?->employee_positions?->positions?->position_level_id != 'psl-1001' && $user->employees->employee_positions?->positions?->is_hod == true ): ?>
                                                <?php if( !empty($user->employees->employee_positions?->second_superior_id)): ?>
                                                    <option selected value="<?php echo e($user->employees?->employee_positions?->second_superior_id); ?>"><?php echo e($second_reports_to); ?></option>
                                                    <option value="">- REMOVE -</option>
                                                <?php else: ?>
                                                    <option selected value="">- Please Select -</option>
                                                <?php endif; ?>
                                                <?php $__currentLoopData = $user_reports_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_reports_to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if( $user_reports_to->employees?->employee_positions?->positions?->subdepartments?->department_id == $user->employees->employee_positions?->positions?->subdepartments?->department_id && $user_reports_to->user_name != $user->user_name): ?>
                                                        <?php if( $user_reports_to?->employees?->employee_positions?->positions?->is_hr_manager == false): ?>
                                                            <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                                <?php echo e($user_reports_to->last_name .', '); ?>

                                                                <?php echo e($user_reports_to->first_name); ?>

                                                                <?php echo e($user_reports_to->middle_name); ?>

                                                            </option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if( $user_reports_to->employees?->employee_positions?->positions?->is_hr_manager == true && $user_reports_to?->user_name != $user->employees->employee_positions?->second_reports_tos?->users?->user_name): ?>
                                                        <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                            <?php echo e($user_reports_to->last_name .', '); ?>

                                                            <?php echo e($user_reports_to->first_name); ?>

                                                            <?php echo e($user_reports_to->middle_name); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                    <?php if( $user_reports_to->employees?->employee_positions?->positions?->position_level_id == 'psl-1001' && $user_reports_to?->user_name != $user->employees->employee_positions?->second_reports_tos?->users?->user_name): ?>
                                                        <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                            <?php echo e($user_reports_to->last_name .', '); ?>

                                                            <?php echo e($user_reports_to->first_name); ?>

                                                            <?php echo e($user_reports_to->middle_name); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php elseif( $user->employees?->employee_positions?->positions?->position_level_id == 'psl-1001'): ?>
                                                <?php if( !empty($user->employees->employee_positions?->second_superior_id)): ?>
                                                    <option selected value="<?php echo e($user->employees?->employee_positions?->second_superior_id); ?>"><?php echo e($second_reports_to); ?></option>
                                                    <option value="">- REMOVE -</option>
                                                <?php else: ?>
                                                    <option selected value="">- Please Select -</option>
                                                <?php endif; ?>
                                                <?php $__currentLoopData = $hrstaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrstaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e(optional($hrstaff)->id); ?>">
                                                        <?php echo e($hrstaff->last_name .', '); ?>

                                                        <?php echo e($hrstaff->first_name); ?>

                                                        <?php echo e($hrstaff->middle_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php if( !empty($user->employees->employee_positions?->second_superior_id)): ?>
                                                    <option selected value="<?php echo e($user->employees?->employee_positions?->second_superior_id); ?>"><?php echo e($second_reports_to); ?></option>
                                                    <option value="">- REMOVE -</option>
                                                <?php else: ?>
                                                    <option selected value="">- Please Select -</option>
                                                <?php endif; ?>
                                                <?php $__currentLoopData = $user_reports_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_reports_to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(optional(optional(optional(optional($user_reports_to->employees)->employee_positions)->positions)->subdepartments)->department_id == optional(optional(optional($user->employees->employee_positions)->positions)->subdepartments)->department_id ): ?>
                                                        <option value="<?php echo e(optional($user_reports_to->employees)->id); ?>">
                                                            <?php echo e($user_reports_to->last_name .', '); ?>

                                                            <?php echo e($user_reports_to->first_name); ?>

                                                            <?php echo e($user_reports_to->middle_name); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mt-3 mb-1">
                                    <?php if($user->employees->employee_position_id == null): ?>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                            <h6 class="profile-title">Department</h6>
                                            <select class="form-control" id="department" name="department">
                                                <option selected disabled value=" ">-- Please Select Here --</option>
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->department_title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12 placeholder-glow">
                                            <h6 class="profile-title">
                                                Sub-department
                                                <div class="spinner-border text-primary spinner-border-sm d-none" id="spinner_subdepartment" role="status" >
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                            </h6>
                                            <select class="form-control" id="subdepartment" name="subdepartment">
                                                <option selected disabled value=" ">-- Please Select Here --</option>
                                                <?php $__currentLoopData = $subdepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subdepartment->id); ?>"><?php echo e($subdepartment->sub_department_title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12 placeholder-glow">
                                            <h6 class="profile-title">
                                                Position
                                                <div class="spinner-border text-primary spinner-border-sm d-none" id="spinner_position" role="status" >
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                            </h6>
                                            <select class="form-control" id="position" name="position" required>
                                                <option selected disabled value=" ">-- Please Select Here --</option>
                                                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($position->id); ?>"><?php echo e($position->position_description); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                            <h6 class="profile-title">Area of assignment</h6>
                                            <select class="form-control" id="area_of_assignment" name="area_of_assignment" required>
                                                <option selected disabled value=" ">-- Please Select Here --</option>
                                                <?php $__currentLoopData = $area_of_assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area_of_assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($area_of_assignment->id); ?>"><?php echo e($area_of_assignment->location_address); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php else: ?>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                            <h6 class="profile-title">Department</h6>
                                            <select class="form-control" id="department" name="department">
                                                <option selected value="<?php echo e(optional($user->employees->employee_positions)->positions->subdepartments->department_id); ?>"><?php echo e(optional(optional($user->employees->employee_positions)->positions)->subdepartments->departments->department_title); ?></option>
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($department->id != optional($user->employees->employee_positions)->positions->subdepartments->department_id): ?>
                                                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->department_title); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12 placeholder-glow">
                                            <h6 class="profile-title">
                                                Sub-department
                                                <div class="spinner-border text-primary spinner-border-sm d-none" id="spinner_subdepartment" role="status" >
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                            </h6>
                                            <select class="form-control" id="subdepartment" name="subdepartment">
                                                <option selected value="<?php echo e(optional($user->employees->employee_positions)->positions->subdepartment_id); ?>"><?php echo e(optional(optional($user->employees->employee_positions)->positions)->subdepartments->sub_department_title); ?></option>
                                                <?php $__currentLoopData = $subdepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($subdepartment->id != optional($user->employees->employee_positions)->positions->subdepartment_id): ?>
                                                        <option value="<?php echo e($subdepartment->id); ?>"><?php echo e($subdepartment->sub_department_title); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12 placeholder-glow">
                                            <h6 class="profile-title">
                                                Position
                                                <div class="spinner-border text-primary spinner-border-sm d-none" id="spinner_position" role="status" >
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                            </h6>
                                            <select class="form-control" id="position" name="position">
                                                <option selected value="<?php echo e(optional($user->employees->employee_positions)->position_id); ?>"><?php echo e(optional(optional($user->employees->employee_positions)->positions)->position_description); ?></option>
                                                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($position->id != optional($user->employees->employee_positions)->position_id): ?>
                                                        <option value="<?php echo e($position->id); ?>"><?php echo e($position->position_description); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-2 col-lg-3 col-md-6 col-sm-12">
                                            <h6 class="profile-title">Area of assignment</h6>
                                            <select class="form-control" id="area_of_assignment" name="area_of_assignment">
                                                <option selected value="<?php echo e(optional($user->employees->employee_positions)->area_of_assignment_id); ?>"><?php echo e(optional(optional($user->employees->employee_positions)->area_of_assignments)->location_address); ?></option>
                                                <?php $__currentLoopData = $area_of_assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area_of_assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($area_of_assignment->id != optional($user->employees->employee_positions)->area_of_assignment_id): ?>
                                                        <option value="<?php echo e($area_of_assignment->id); ?>"><?php echo e($area_of_assignment->location_address); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <h3>Account details</h3>
                        </div>
                        <div class="row mt-1">
                            <div class="row mt-2 mb-1">
                                <div class="mb-2 col-lg-6 col-md-6 col-sm-12">
                                    <h6 class="profile-title">Email</h6>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
                                </div>
                            </div>
                            <div class="row mt-2 mb-1">
                                <div class="mb-2 col-lg-6 col-md-6 col-sm-12">
                                    <h6 class="profile-title">User name</h6>
                                    <input type="text" class="form-control" id="user_name" name="user_name" value="<?php echo e($user->user_name); ?>">
                                </div>
                            </div>
                            <div class="row mt-2 mb-1">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <h6 class="profile-title">Password</h6>
                                        <div class="input-group">
                                            <input type="password" class="form-control" id="password" placeholder="" name="password" value="<?php echo e(old('password')); ?>">
                                            <button type="button" class="btn rounded-end btn-outline-primary" id="show_password" onclick="showPass()">
                                                show
                                            </button>
                                            <button type="button" class="btn rounded-end btn-warning" id="hide_password" onclick="hidePass()" hidden>
                                                hide
                                            </button>
                                        </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <h6 class="profile-title">Retype Password</h6>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>">
                                        <button type="button" class="btn rounded-end btn-outline-primary" id="show_repassword" onclick="showRePass()">
                                            show
                                        </button>
                                        <button type="button" class="btn rounded-end btn-warning" id="hide_repassword" onclick="hideRePass()" hidden>
                                            hide
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-1 mb-1">
                                <div class="mb-2 col-lg-4 d-grid gap-2 col-md-6 col-sm-12">
                                    <a href="#" class="profile-title-value btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#reset_password_modal">reset password</a>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3 mb-5">
                            <div class="mb-2 col-lg-6 col-md-6 col-sm-12 text-end d-grid gap-2 mx-auto">
                                <button id="submit_button2" type="submit" class="btn btn-success">Save Changes</button>
                                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger">Discard Changes</a>
                            </div>
                        </div>
                    </div>
                    <script>
                        $(document).ready(function(){
                            $('#department').on('change',function(){
                                let id = $(this).val();
                                $('#subdepartment').empty();
                                $('#subdepartment').addClass('placeholder');
                                $('#position').addClass('placeholder');
                                $('#spinner_subdepartment').removeClass('d-none');
                                $('#spinner_position').removeClass('d-none');
                                $('#subdepartment').append('<option value="0" disabled selected >Processing...</option>');
                                $('#position').append('<option value="0" disabled selected>Processing...</option>');
                                $.ajax({
                                    type: 'GET',
                                    url: '/addAccount/getSubdepartment/'+id,
                                    success: function (response){
                                        var response = JSON.parse(response);
                                        console.log(response);
                                        $('#subdepartment').empty();
                                        $('#position').empty();
                                        $('#subdepartment').removeClass('placeholder');
                                        $('#position').removeClass('placeholder');
                                        $('#spinner_subdepartment').addClass('d-none');
                                        $('#spinner_position').addClass('d-none');
                                        $('#subdepartment').append('<option value="0" disabled selected>*Select Sub-department</option>');
                                        $('#position').append('<option value="0" disabled selected>*Select Sub-department</option>');
                                        response.forEach(element => {
                                            $('#subdepartment').append(`<option value="${element['id']}">${element['sub_department_title']}</option>`);
                                        });
                                    }
                                });
                            });
                            $('#subdepartment').on('change',function(){
                                let id = $(this).val();
                                $('#position').empty();
                                $('#position').append('<option value="0" disabled selected>Processing...</option>');
                                $('#position').addClass('placeholder');
                                $('#spinner_position').removeClass('d-none');
                                $.ajax({
                                    type: 'GET',
                                    url: '/addAccount/getPosition/'+id,
                                    success: function (response){
                                        var response = JSON.parse(response);
                                        console.log(response);
                                        $('#position').empty();
                                        $('#position').removeClass('placeholder');
                                        $('#spinner_position').addClass('d-none');
                                        $('#position').append('<option value="0" disabled selected>*Select Position</option>');
                                        response.forEach(element => {
                                            $('#position').append(`<option value="${element['id']}">${element['position_description']}</option>`);
                                        });
                                    }
                                });
                            });
                        });
                    </script>
                </form>
                
                <!-- confirm reset password Modal -->
                    <div class="modal fade" id="reset_password_modal" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="container-fluid text-start">
                                        <div class="row">
                                            <div class="col text-center">
                                                <h2>Please confirm to reset the password</h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-transparent" data-bs-dismiss="modal">Close</button>
                                    <form action="<?php echo e(route('account_reset_password',['username'=>$user->user_name])); ?>" method="PUT" onsubmit="onClickApprove()">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger" type="submit">Confirm</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.hrstaff_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BioseedLeaveManagementSystem\resources\views/profiles/hr_staff/employee_management/visit_user_update.blade.php ENDPATH**/ ?>