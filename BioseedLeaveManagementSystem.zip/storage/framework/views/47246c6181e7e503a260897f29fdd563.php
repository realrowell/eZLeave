<?php $__env->startSection('grid_active','bg-selected-warning'); ?>
<?php $__env->startSection('sub-content'); ?>

<div class="row mt-2">
    <div class="col-lg-6 col-md-6 col-sm-12">

    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="row">
            <form action="<?php echo e(route('admin_accounts_search_grid')); ?>" onkeyup="searchBtnEnable()">
            <?php echo csrf_field(); ?>
                <div class="input-group shadow-sm">
                    <input type="search" class="form-control rounded" name="search_input" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                    <button type="submit" class="btn btn-primary disabled" id="search_btn">search</button>
                </div>
            </form>
        </div>
        <div class="row">
            <p>*Search employee by first name or by last name here</p>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row justify-content-sm-center justify-content-md-center justify-content-lg-center ">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 col-sm-10 align-self-stretch p-1  ">
            <div class="shadow card">
                <div class="card-body row p-3">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-4">
                        <?php if($user->profile_photos == null): ?>
                            <img class="profile-photo-sm" src="/img/dummy_profile.jpg" alt="profile photo">
                        <?php else: ?>
                            <img class="profile-photo-sm" src="<?php echo e(asset('storage/images/profile_photos/'.$user->profile_photos->profile_photo)); ?>" alt="profile photo">
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-7 col-md-7 col-sm-7 col-7">
                        <div class="row">
                            <h5><strong><?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?> <?php echo e($user->middle_name); ?> <?php echo e(optional($user->suffixes)->suffix_title); ?></strong></h5>
                        </div>
                        <div class="row">
                            <?php if($user->role_id != 'rol-0003'): ?>
                                <p class="card-desc"><?php echo e(optional($user->roles)->role_title); ?></p>
                                <div class="col">
                                    <?php if($user->status_id == 'sta-2001'): ?>
                                        <p class="card-desc badge bg-success"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2002'): ?>
                                        <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2003'): ?>
                                        <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2004'): ?>
                                        <p class="card-desc badge bg-danger"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2002'): ?>
                                        <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <p class="card-desc"><?php echo e(optional(optional(optional($user->employees)->employee_positions)->positions)->position_description); ?></p>
                                <p class="card-desc"><?php echo e(optional(optional(optional($user->employees)->employee_positions)->subdepartments)->sub_department_title); ?></p>
                                <div class="col">
                                    <?php if($user->status_id == 'sta-2001'): ?>
                                        <p class="card-desc badge bg-success"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2002'): ?>
                                        <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2003'): ?>
                                        <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2004'): ?>
                                        <p class="card-desc badge bg-danger"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php elseif($user->status_id == 'sta-2002'): ?>
                                        <p class="card-desc badge bg-warning text-dark"><?php echo e(optional($user->statuses)->status_title); ?></p>
                                    <?php endif; ?>
                                </div>
                                
                            <?php endif; ?>
                        </div>
                        <div class="row mt-2">
                            <div class="col">
                                <?php if($user->role_id != 'rol-0003'): ?>
                                    <a href="<?php echo e(route('admin_visit_account_view',['username'=>$user->user_name])); ?>" class="btn-sm btn-primary text-center">Profile</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin_visit_employee_view',['username'=>$user->user_name])); ?>" class="btn-sm btn-primary text-center">Profile</a>
                                    <a href="<?php echo e(route('visit_employee_leave_ms_view',['username'=>$user->user_name])); ?>" class="btn-sm btn-primary text-center">Leave-MS</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

    </div>
</div>
<div class="row">
    <div class="col">
        <div class="mt-5">
            <ul class="pagination justify-content-center align-items-center">
                <?php echo $users->links('pagination::bootstrap-5'); ?>

            </ul>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.admin.account_management.accounts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BioseedLeaveManagementSystem\resources\views/profiles/admin/account_management/accounts_grid_view.blade.php ENDPATH**/ ?>